/* Shared vector icons for home.html and panel.html (no external files, works offline). */
(function () {
  var gear = '<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="6.6"/>';
  for (var k = 0; k < 8; k++) {
    var a = k * Math.PI / 4, c = Math.cos(a), s = Math.sin(a);
    gear += '<path d="M' + (12 + 6.6 * c).toFixed(2) + ' ' + (12 + 6.6 * s).toFixed(2) +
      'L' + (12 + 9.6 * c).toFixed(2) + ' ' + (12 + 9.6 * s).toFixed(2) + '"/>';
  }
  var F = 'fill="currentColor" stroke="none"';
  var P = {
    back: '<path d="M15 5l-7 7 7 7"/>',
    chev: '<path d="M9 6l6 6-6 6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    search: '<circle cx="10.5" cy="10.5" r="6"/><path d="M15 15l5 5"/>',
    dots: '<circle cx="12" cy="5" r="1.9" ' + F + '/><circle cx="12" cy="12" r="1.9" ' + F + '/><circle cx="12" cy="19" r="1.9" ' + F + '/>',
    incog: '<path d="M5 11l2.5-6.5h9L19 11"/><path d="M3 11h18"/><circle cx="8" cy="16.5" r="2.6"/><circle cx="16" cy="16.5" r="2.6"/><path d="M10.6 16h2.8"/>',
    bookmark: '<path d="M7 4h10v16l-5-4-5 4z"/>',
    clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3.2 2"/>',
    download: '<path d="M12 4v10.5M7.5 10.5L12 15l4.5-4.5M5 19h14"/>',
    desktop: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M12 16v4M8 20h8"/>',
    desktopf: '<path ' + F + ' d="M4 4h16a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1h-6v2h3v2H7v-2h3v-2H4a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z"/>',
    ext: '<path ' + F + ' d="M20.5 11H19V7c0-1.1-.9-2-2-2h-4V3.5C13 2.12 11.88 1 10.5 1S8 2.12 8 3.5V5H4c-1.1 0-2 .9-2 2v3.8h1.5c1.49 0 2.7 1.21 2.7 2.7s-1.21 2.7-2.7 2.7H2V20c0 1.1.9 2 2 2h3.8v-1.5c0-1.49 1.21-2.7 2.7-2.7s2.7 1.21 2.7 2.7V22H17c1.1 0 2-.9 2-2v-4h1.5c1.38 0 2.5-1.12 2.5-2.5S21.88 11 20.5 11z"/>',
    gear: gear,
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.6 9.4a2.5 2.5 0 1 1 3.7 2.2c-.9.5-1.3 1-1.3 2"/><path d="M12 16.8v.1"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.8v.1"/>',
    exit: '<path d="M10 4H5v16h5M9.5 12H20M16 8l4 4-4 4"/>',
    refresh: '<path d="M20 12a8 8 0 1 1-2.4-5.7M20 4v5h-5"/>',
    copy: '<rect x="9" y="9" width="10.5" height="10.5" rx="2"/><path d="M5 14.5V5h9.5"/>',
    share: '<circle cx="6" cy="12" r="2.4"/><circle cx="18" cy="5.8" r="2.4"/><circle cx="18" cy="18.2" r="2.4"/><path d="M8.2 10.9l7.6-4M8.2 13.1l7.6 4"/>',
    star: '<path ' + F + ' d="M12 3.1l2.41 6.18 6.62.38-5.13 4.2 1.68 6.43L12 16.7l-5.58 3.59 1.68-6.43-5.13-4.2 6.62-.38z"/>',
    starline: '<path d="M12 3.1l2.41 6.18 6.62.38-5.13 4.2 1.68 6.43L12 16.7l-5.58 3.59 1.68-6.43-5.13-4.2 6.62-.38z"/>',
    crown: '<path d="M3 18l1.5-10 4.2 4.5L12 6l3.3 6.5L19.5 8 21 18z"/><path d="M3.5 21h17"/>',
    crownf: '<path ' + F + ' d="M3 18l1.5-10 4.2 4.5L12 6l3.3 6.5L19.5 8 21 18z"/><rect ' + F + ' x="3.5" y="19.6" width="17" height="2" rx="1"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    trash: '<path d="M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13M10 11v6M14 11v6"/>',
    bolt: '<path ' + F + ' d="M13.5 2.5l-8 11H11l-1 8 8.5-11.5H12.5z"/>',
    lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    play: '<path ' + F + ' d="M8 5v14l11-7z"/>',
    music: '<path d="M9 18V6l10-2v12"/><circle cx="7" cy="18" r="2.2"/><circle cx="17" cy="16" r="2.2"/>',
    file: '<path d="M7 3h7l5 5v13H7zM14 3v5h5"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2.2 2.2L15.5 10"/>',
    moon: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
    text: '<path d="M4 19l5-14 5 14M6 14h6M15 11h5M17.5 11v8"/>',
    up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
    down: '<path d="M12 5v14M6 13l6 6 6-6"/>',
    tabs: '<rect x="4" y="4" width="16" height="16" rx="3"/>'
  };
  var B = {
    youtube: '<svg viewBox="0 0 24 24"><rect x="1.5" y="5" width="21" height="14" rx="4.5" fill="#f00"/><path d="M10 8.8v6.4l5.6-3.2z" fill="#fff"/></svg>',
    facebook: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10.5" fill="#1877f2"/><path fill="#fff" d="M13.3 21.4v-7.6h2.5l.4-3h-2.9V9c0-.9.3-1.4 1.5-1.4h1.5V4.9c-.3 0-1.2-.1-2.2-.1-2.2 0-3.7 1.3-3.7 3.800v2.200H8v3h2.4v7.600z"/></svg>',
    messenger: '<svg viewBox="0 0 24 24"><defs><linearGradient id="gm" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#0099ff"/><stop offset=".5" stop-color="#a033ff"/><stop offset="1" stop-color="#ff5280"/></linearGradient></defs><circle cx="12" cy="12" r="10.5" fill="url(#gm)"/><path fill="#fff" d="M12 4.6c-4.2 0-7.4 3.100-7.4 7.200 0 2.200 1 4.100 2.600 5.400v2.800l2.600-1.400c.7.200 1.400.3 2.200.3 4.200 0 7.400-3.100 7.400-7.100S16.200 4.600 12 4.600z"/><path fill="url(#gm)" d="M6.900 14.300l3.600-3.800 2.100 2 3.700-2-3.600 3.900-2.100-2z"/></svg>',
    whatsapp: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10.5" fill="#25d366"/><circle cx="12" cy="11.7" r="5.6" fill="none" stroke="#fff" stroke-width="1.7"/><path d="M9.6 9.6l4.8 4.8" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/><path fill="#fff" d="M6.2 18.2l1.2-3.800 2.400 2.200z"/></svg>',
    telegram: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10.5" fill="#2aabee"/><path fill="#fff" d="M5.4 11.800l13-5-2.500 11-3.900-2.800-2 2.200-.4-3.600 6.400-5.200-8 4.300z"/></svg>',
    x: '<svg viewBox="0 0 24 24"><path d="M6.200 5.200l11.600 13.600M17.800 5.200L6.200 18.800" stroke="#fff" stroke-width="2.200" stroke-linecap="round" fill="none"/></svg>',
    instagram: '<svg viewBox="0 0 24 24"><defs><linearGradient id="gi" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#feda75"/><stop offset=".4" stop-color="#d62976"/><stop offset="1" stop-color="#4f5bd5"/></linearGradient></defs><circle cx="12" cy="12" r="10.5" fill="url(#gi)"/><rect x="6.500" y="6.500" width="11" height="11" rx="3.200" fill="none" stroke="#fff" stroke-width="1.600"/><circle cx="12" cy="12" r="2.600" fill="none" stroke="#fff" stroke-width="1.600"/><circle cx="15.400" cy="8.600" r=".8" fill="#fff"/></svg>',
    discord: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10.5" fill="#5865f2"/><path fill="#fff" d="M16.800 8.200a10 10 0 0 0-2.500-.8l-.3.6a9 9 0 0 0-3.900 0l-.3-.6a10 10 0 0 0-2.500.8C5.700 10.600 5.300 12.900 5.500 15.200c1 .8 2.100 1.200 3.100 1.500l.7-1.100c-.4-.2-.8-.4-1.100-.6l.3-.2c2.100.9 4.400.9 6.500 0l.3.200c-.4.200-.7.400-1.100.6l.7 1.100c1.100-.3 2.100-.8 3.100-1.500.3-2.600-.5-4.800-1.700-7zM9.900 13.500c-.6 0-1-.5-1-1.100s.4-1.100 1-1.100 1 .5 1 1.100-.4 1.100-1 1.100zm4.200 0c-.6 0-1-.5-1-1.100s.4-1.100 1-1.100 1 .5 1 1.100-.4 1.100-1 1.100z"/></svg>',
    imo: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10.5" fill="#1b8cf0"/><text x="12" y="15" font-size="8" font-weight="800" text-anchor="middle" fill="#fff" font-family="Arial,sans-serif">imo</text></svg>',
    likee: '<svg viewBox="0 0 24 24"><defs><linearGradient id="gl" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#ff4fa8"/><stop offset="1" stop-color="#ff9d3a"/></linearGradient></defs><circle cx="12" cy="12" r="10.5" fill="url(#gl)"/><path fill="#fff" d="M12 18s-5.500-3.500-5.500-7.400C6.500 8.600 7.900 7.300 9.600 7.300c1 0 1.900.5 2.400 1.300.5-.8 1.400-1.300 2.400-1.300 1.700 0 3.100 1.300 3.100 3.300C17.500 14.500 12 18 12 18z"/></svg>',
    tiktok: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10.5" fill="#111"/><path d="M13.200 6v7.600a2.300 2.300 0 1 1-2.300-2.300M13.200 6c.2 1.600 1.300 2.700 3 2.900" fill="none" stroke="#25f4ee" stroke-width="1.700" stroke-linecap="round" transform="translate(-.5 .3)"/><path d="M13.200 6v7.600a2.300 2.300 0 1 1-2.300-2.300M13.200 6c.2 1.600 1.300 2.700 3 2.900" fill="none" stroke="#fe2c55" stroke-width="1.700" stroke-linecap="round" transform="translate(.5 -.3)"/></svg>',
    more: '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.7"><circle cx="7.500" cy="7.500" r="3"/><circle cx="16.500" cy="7.500" r="3"/><circle cx="7.500" cy="16.500" r="3"/><circle cx="16.500" cy="16.500" r="3"/></svg>',
    google: '<span class="gG">G</span>'
  };
  window.ic = function (n, cls) {
    return '<svg class="ic ' + (cls || '') + '" viewBox="0 0 24 24" aria-hidden="true">' + (P[n] || '') + '</svg>';
  };
  window.brand = function (n) { return B[n] || ''; };
})();
