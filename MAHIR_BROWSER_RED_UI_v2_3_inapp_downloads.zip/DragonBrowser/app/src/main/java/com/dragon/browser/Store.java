package com.dragon.browser;

import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

/** Bookmarks / history kept as a JSON array of {t: title, u: url, ts: time} in SharedPreferences. */
final class Store {
    private Store() {
    }

    /** Reads the list; old versions stored plain newline-separated URLs, which are converted here. */
    static JSONArray array(SharedPreferences p, String key) {
        String raw = p.getString(key, "");
        try {
            if (raw.startsWith("[")) return new JSONArray(raw);
        } catch (Exception ignored) {
            return new JSONArray();
        }
        JSONArray a = new JSONArray();
        if (raw.length() == 0) return a;
        long now = System.currentTimeMillis();
        try {
            String[] lines = raw.split("\\n");
            for (int i = lines.length - 1; i >= 0; i--) {
                if (lines[i].trim().length() == 0) continue;
                JSONObject o = new JSONObject();
                o.put("t", "");
                o.put("u", lines[i].trim());
                o.put("ts", now - (lines.length - i) * 1000L);
                a.put(o);
            }
        } catch (Exception ignored) {
        }
        return a;
    }

    private static void save(SharedPreferences p, String key, JSONArray a) {
        p.edit().putString(key, a.toString()).apply();
    }

    static boolean has(SharedPreferences p, String key, String url) {
        JSONArray a = array(p, key);
        for (int i = 0; i < a.length(); i++) {
            if (url.equals(a.optJSONObject(i) == null ? "" : a.optJSONObject(i).optString("u"))) return true;
        }
        return false;
    }

    /** Adds to the front; an existing entry with the same url is replaced (moved up). */
    static void add(SharedPreferences p, String key, String title, String url, int max) {
        if (url == null || url.length() == 0) return;
        JSONArray old = array(p, key);
        JSONArray a = new JSONArray();
        try {
            JSONObject n = new JSONObject();
            n.put("t", title == null ? "" : title);
            n.put("u", url);
            n.put("ts", System.currentTimeMillis());
            a.put(n);
            for (int i = 0; i < old.length() && a.length() < max; i++) {
                JSONObject o = old.optJSONObject(i);
                if (o != null && !url.equals(o.optString("u"))) a.put(o);
            }
        } catch (Exception ignored) {
        }
        save(p, key, a);
    }

    static void remove(SharedPreferences p, String key, int index) {
        JSONArray old = array(p, key);
        JSONArray a = new JSONArray();
        for (int i = 0; i < old.length(); i++) if (i != index) a.put(old.opt(i));
        save(p, key, a);
    }

    static void clear(SharedPreferences p, String key) {
        p.edit().remove(key).apply();
    }
}
