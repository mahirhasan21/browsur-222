package com.dragon.browser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.Window;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    static final String HOME = "file:///android_asset/home.html";
    static final String EXT_HOST = "dm.ext";
    private static final int REQ_FILE = 11;
    private static final int REQ_ZIP = 12;
    private static final int REQ_PERM = 13;
    private static final int REQ_STORAGE = 14;
    private static final int REQ_LOC = 15;
    private static final int REQ_ROLE = 16;

    // ------------------------------------------------------------------ state
    Ext ext;
    volatile int curId;
    volatile String curUrl = "";
    volatile String curTitle = "";

    private SharedPreferences prefs;
    private boolean desktop;
    private boolean adblock;
    private boolean savehist;
    private boolean keepOn;
    private boolean docStart;
    private String mobileUA;
    private String desktopUA;

    // look & feel / preferences (written from the JS bridge thread, so volatile)
    private volatile String theme = "system";   // system | light | dark
    private volatile String lang = "system";    // system | en | bn
    private volatile String engine = "google";  // google | bing | ddg | yahoo | brave
    private volatile int textSize = 100;
    private volatile boolean webdark = true;

    private FrameLayout rootFrame;
    private FrameLayout content;
    private EditText urlBar;
    private ProgressBar progress;
    private TextView tabCount;
    private LinearLayout main, top, pill, bottom, findBar;
    private View line;
    private TextView engineBtn, findCount;
    private EditText findInput;
    private UiKit.Ico homeIco, dotsIco, reloadIco, findUp, findDown, findClose;
    private boolean loading;
    private BroadcastReceiver dlReceiver;
    private String[] pendingDl;
    private String blobToken;
    private String geoOrigin;
    private GeolocationPermissions.Callback geoCb;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LinearLayout snackBar;
    private TextView snackMsg, snackAct;

    private final ArrayList<Tab> tabs = new ArrayList<>();
    private Tab cur;
    private int tabSeq = 0;

    private final Map<WebView, ScriptHandler> handles = new HashMap<>();
    private final Map<String, BgPage> bgs = new HashMap<>();
    private final ArrayList<WebView> popupViews = new ArrayList<>();
    private final Map<Integer, Pending> pending = new HashMap<>();
    private int respSeq = 0;

    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private ValueCallback<Uri[]> fileCb;
    private PermissionRequest pendingPerm;

    static final class Tab {
        int id;
        WebView wv;
        String title = "";
        String url = "";
        boolean privateMode = false;
    }

    static final class BgPage {
        String extId;
        WebView wv;
        boolean loaded;
        final ArrayList<Runnable> queue = new ArrayList<>();

        void post(Runnable r) {
            if (loaded) r.run();
            else queue.add(r);
        }
    }

    static final class Pending {
        final WeakReference<WebView> wv;
        final int cb;

        Pending(WebView w, int cb) {
            this.wv = new WeakReference<>(w);
            this.cb = cb;
        }
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("browser", MODE_PRIVATE);
        desktop = prefs.getBoolean("desktop", false);
        adblock = prefs.getBoolean("adblock", true);
        savehist = prefs.getBoolean("savehist", true);
        keepOn = prefs.getBoolean("keepon", false);
        theme = prefs.getString("theme", "system");
        lang = prefs.getString("lang", "system");
        engine = prefs.getString("engine", "google");
        textSize = prefs.getInt("textSize", 100);
        webdark = prefs.getBoolean("webdark", true);
        ext = new Ext(this);

        String def = WebSettings.getDefaultUserAgent(this);
        mobileUA = def.replace("; wv", "").replace("Version/4.0 ", "");
        Matcher m = Pattern.compile("Chrome/([\\d.]+)").matcher(def);
        String ver = m.find() ? m.group(1) : "120.0.0.0";
        desktopUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + ver + " Safari/537.36";

        boolean ds = false;
        try {
            ds = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        } catch (Throwable ignored) {
        }
        docStart = ds;

        buildUi();
        applyKeepOn();
        registerDownloadReceiver();
        refreshExtensions();

        Uri data = getIntent() == null ? null : getIntent().getData();
        createTab(data != null ? data.toString() : HOME, null);
        if (b == null) getWindow().getDecorView().post(this::showSplash);
        if (getIntent() != null && getIntent().getBooleanExtra("openDownloads", false)) {
            getWindow().getDecorView().postDelayed(() -> showPanel("downloads"), 2200);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Uri data = intent == null ? null : intent.getData();
        if (data != null) createTab(data.toString(), null);
        if (intent != null && intent.getBooleanExtra("openDownloads", false)) {
            getWindow().getDecorView().post(() -> showPanel("downloads"));
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onDestroy() {
        if (dlReceiver != null) {
            try {
                unregisterReceiver(dlReceiver);
            } catch (Exception ignored) {
            }
            dlReceiver = null;
        }
        for (Tab t : tabs) {
            try {
                t.wv.destroy();
            } catch (Exception ignored) {
            }
        }
        if (hasPrivateTabs()) CookieManager.getInstance().setAcceptCookie(true);
        for (BgPage bg : bgs.values()) {
            try {
                bg.wv.destroy();
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustom();
            return;
        }
        if (findBar != null && findBar.getVisibility() == View.VISIBLE) {
            hideFind();
            return;
        }
        if (urlBar != null && urlBar.hasFocus()) {
            urlBar.clearFocus();
            hideKeyboard(urlBar);
            return;
        }
        if (cur != null && cur.wv.canGoBack()) {
            cur.wv.goBack();
            return;
        }
        if (tabs.size() > 1) {
            closeTab(cur);
            return;
        }
        super.onBackPressed();
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if ("system".equals(theme)) applyTheme();
    }

    // ------------------------------------------------------------------ look & feel

    boolean isDark() {
        if ("dark".equals(theme)) return true;
        if ("light".equals(theme)) return false;
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    String rlang() {
        if ("bn".equals(lang) || "en".equals(lang)) return lang;
        return "bn".equals(Locale.getDefault().getLanguage()) ? "bn" : "en";
    }

    String tr(String en, String bn) {
        return "bn".equals(rlang()) ? bn : en;
    }

    private AlertDialog.Builder dlg() {
        return new AlertDialog.Builder(new ContextThemeWrapper(this,
                isDark() ? android.R.style.Theme_Material_Dialog_Alert : android.R.style.Theme_Material_Light_Dialog_Alert));
    }

    private void hideKeyboard(View v) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null && v != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    private void applySystemBars() {
        boolean dk = isDark();
        Window w = getWindow();
        w.setStatusBarColor(dk ? 0xFF000000 : 0xFFFFFFFF);
        w.setNavigationBarColor(dk ? 0xFF0B0B0B : 0xFFFFFFFF);
        int f = 0;
        if (!dk) {
            f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        w.getDecorView().setSystemUiVisibility(f);
    }

    private void applyWebDark(WebSettings st) {
        boolean want = isDark() && webdark;
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
                WebSettingsCompat.setAlgorithmicDarkeningAllowed(st, want);
            } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                WebSettingsCompat.setForceDark(st, want ? WebSettingsCompat.FORCE_DARK_ON : WebSettingsCompat.FORCE_DARK_OFF);
            }
        } catch (Throwable ignored) {
        }
    }

    private void reloadHomeTabs() {
        for (Tab t : tabs) {
            if (t.url != null && t.url.startsWith(HOME)) t.wv.reload();
        }
    }

    /** Re-colours every native view (and tells open web views) after a theme / language / setting change. */
    void applyTheme() {
        if (main == null) return;
        boolean dk = isDark();
        applySystemBars();
        int ico = dk ? 0xFFFFFFFF : 0xFF26262B;
        main.setBackgroundColor(dk ? 0xFF000000 : 0xFFF4F4F6);
        top.setBackgroundColor(dk ? 0xFF000000 : 0xFFFFFFFF);
        pill.setBackground(roundBg(dk ? 0xFF181818 : 0xFFF0F0F3, dk ? 0xFF3A1317 : 0xFFE9C9CC, 22));
        urlBar.setTextColor(dk ? 0xFFFFFFFF : 0xFF17171A);
        urlBar.setHintTextColor(dk ? 0xFF9A9A9A : 0xFF7A7A82);
        engineBtn.setTextColor(RED);
        reloadIco.setColor(ico);
        bottom.setBackgroundColor(dk ? 0xFF0B0B0B : 0xFFFFFFFF);
        line.setBackgroundColor(dk ? 0xFF1C1C1C : 0xFFE3E3E7);
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(dk ? 0xFF1A1A1A : 0xFFE3E3E7));
        navBack.setColor(ico);
        navFwd.setColor(ico);
        dotsIco.setColor(ico);
        findBar.setBackgroundColor(dk ? 0xFF111111 : 0xFFFFFFFF);
        findInput.setTextColor(dk ? 0xFFFFFFFF : 0xFF17171A);
        findInput.setHintTextColor(dk ? 0xFF9A9A9A : 0xFF7A7A82);
        findCount.setTextColor(dk ? 0xFFBBBBBB : 0xFF55555B);
        findUp.setColor(ico);
        findDown.setColor(ico);
        findClose.setColor(ico);
        findInput.setHint(tr("Find in page", "পেজে খুঁজুন"));
        for (Tab t : tabs) {
            t.wv.setBackgroundColor(dk ? Color.BLACK : 0xFFF4F4F6);
            applyWebDark(t.wv.getSettings());
        }
        if (panelDialog != null && panelWv != null) {
            panelWv.setBackgroundColor(dk ? Color.BLACK : 0xFFF4F4F6);
            if (panelDialog.getWindow() != null) styleDialogWindow(panelDialog.getWindow(), dk);
        }
        refreshBar();
        reloadHomeTabs();
    }

    private void styleDialogWindow(Window w, boolean dk) {
        w.setStatusBarColor(dk ? Color.BLACK : 0xFFF4F4F6);
        w.setNavigationBarColor(dk ? Color.BLACK : 0xFFF4F4F6);
        int f = 0;
        if (!dk) {
            f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        w.getDecorView().setSystemUiVisibility(f);
    }

    private static final String[][] ENGINES = {
            {"google", "Google", "https://www.google.com/search?q=", "G"},
            {"bing", "Bing", "https://www.bing.com/search?q=", "b"},
            {"ddg", "DuckDuckGo", "https://duckduckgo.com/?q=", "D"},
            {"yahoo", "Yahoo", "https://search.yahoo.com/search?p=", "Y"},
            {"brave", "Brave Search", "https://search.brave.com/search?q=", "B"}
    };

    private String[] engineRow() {
        for (String[] e : ENGINES) if (e[0].equals(engine)) return e;
        return ENGINES[0];
    }

    private void chooseEngine() {
        String[] names = new String[ENGINES.length];
        int sel = 0;
        for (int i = 0; i < ENGINES.length; i++) {
            names[i] = ENGINES[i][1];
            if (ENGINES[i][0].equals(engine)) sel = i;
        }
        dlg().setTitle(tr("Search engine", "সার্চ ইঞ্জিন"))
                .setSingleChoiceItems(names, sel, (d, which) -> {
                    setEngine(ENGINES[which][0]);
                    d.dismiss();
                })
                .setNegativeButton(tr("Cancel", "বাতিল"), null)
                .show();
    }

    void setEngine(String e) {
        engine = e;
        prefs.edit().putString("engine", e).apply();
        runOnUiThread(this::refreshBar);
    }

    // ------------------------------------------------------------------ UI

    private static final int RED = 0xFFE31B23;

    private UiKit.Ico navBack;
    private UiKit.Ico navFwd;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable roundBg(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private LinearLayout cell(View inner, int sizeDp, View.OnClickListener l) {
        LinearLayout c = new LinearLayout(this);
        c.setGravity(Gravity.CENTER);
        c.addView(inner, new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        c.setOnClickListener(l);
        return c;
    }

    private void buildUi() {
        rootFrame = new FrameLayout(this);
        main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);

        // top bar: [ engine | search pill | reload ] [messenger]
        top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(8), dp(12), dp(8));

        pill = new LinearLayout(this);
        pill.setGravity(Gravity.CENTER_VERTICAL);

        engineBtn = new TextView(this);
        engineBtn.setGravity(Gravity.CENTER);
        engineBtn.setTypeface(Typeface.DEFAULT_BOLD);
        engineBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        engineBtn.setOnClickListener(v -> chooseEngine());
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.MATCH_PARENT);
        gp.leftMargin = dp(6);
        pill.addView(engineBtn, gp);

        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        urlBar.setBackground(null);
        urlBar.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBar.setSelectAllOnFocus(true);
        urlBar.setPadding(dp(4), 0, dp(4), 0);
        urlBar.setOnEditorActionListener((v, actionId, event) -> {
            boolean enter = event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN;
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                loadInput(urlBar.getText().toString());
                urlBar.clearFocus();
                hideKeyboard(urlBar);
                return true;
            }
            return false;
        });
        urlBar.setOnFocusChangeListener((v, has) -> {
            if (has) {
                urlBar.setText(cur != null && cur.url != null && !cur.url.startsWith("file:") ? cur.url : "");
                urlBar.selectAll();
            } else {
                refreshBar();
            }
            updateReloadIcon();
        });
        pill.addView(urlBar, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        reloadIco = new UiKit.Ico(this, UiKit.REFRESH, 0xFFFFFFFF);
        pill.addView(cell(reloadIco, 20, v -> onReloadClick()), new LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.MATCH_PARENT));
        top.addView(pill, new LinearLayout.LayoutParams(0, dp(44), 1f));

        UiKit.Ico mess = new UiKit.Ico(this, UiKit.B_MESSENGER, 0);
        mess.setOnClickListener(v -> openMessenger());
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(dp(40), dp(40));
        ml.leftMargin = dp(10);
        top.addView(mess, ml);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(RED));
        progress.setVisibility(View.GONE);

        buildFindBar();

        content = new FrameLayout(this);

        // bottom bar: back, forward, home, tabs, menu
        bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams cellLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);

        navBack = new UiKit.Ico(this, UiKit.BACK, 0xFFFFFFFF);
        navFwd = new UiKit.Ico(this, UiKit.FORWARD, 0xFFFFFFFF);
        homeIco = new UiKit.Ico(this, UiKit.HOME, RED);
        dotsIco = new UiKit.Ico(this, UiKit.DOTS, 0xFFFFFFFF);
        bottom.addView(cell(navBack, 26, v -> {
            if (cur != null && cur.wv.canGoBack()) cur.wv.goBack();
        }), cellLp);
        bottom.addView(cell(navFwd, 26, v -> {
            if (cur != null && cur.wv.canGoForward()) cur.wv.goForward();
        }), new LinearLayout.LayoutParams(cellLp));
        bottom.addView(cell(homeIco, 28, v -> {
            if (cur != null) cur.wv.loadUrl(HOME);
        }), new LinearLayout.LayoutParams(cellLp));

        tabCount = new TextView(this);
        tabCount.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tabCount.setTypeface(Typeface.DEFAULT_BOLD);
        tabCount.setGravity(Gravity.CENTER);
        bottom.addView(cell(tabCount, 22, v -> showTabs()), new LinearLayout.LayoutParams(cellLp));
        bottom.addView(cell(dotsIco, 24, v -> showMenu()), new LinearLayout.LayoutParams(cellLp));

        line = new View(this);

        main.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)));
        main.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));
        main.addView(findBar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        main.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        main.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        main.addView(bottom, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));

        rootFrame.addView(main, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(rootFrame);
        applyTheme();
    }

    private void onReloadClick() {
        if (urlBar.hasFocus()) {
            urlBar.setText("");
            return;
        }
        if (cur == null) return;
        if (loading) cur.wv.stopLoading();
        else cur.wv.reload();
    }

    private void updateReloadIcon() {
        if (reloadIco == null || urlBar == null) return;
        reloadIco.setType(urlBar.hasFocus() || loading ? UiKit.CLOSE : UiKit.REFRESH);
    }

    // ------------------------------------------------------------------ find in page

    private void buildFindBar() {
        findBar = new LinearLayout(this);
        findBar.setOrientation(LinearLayout.HORIZONTAL);
        findBar.setGravity(Gravity.CENTER_VERTICAL);
        findBar.setPadding(dp(14), 0, dp(6), 0);
        findBar.setVisibility(View.GONE);

        findInput = new EditText(this);
        findInput.setSingleLine(true);
        findInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        findInput.setBackground(null);
        findInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        findInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence a, int b, int c, int d) {
            }

            @Override
            public void onTextChanged(CharSequence a, int b, int c, int d) {
            }

            @Override
            public void afterTextChanged(Editable e) {
                if (cur == null) return;
                String q = e.toString();
                if (q.length() == 0) {
                    cur.wv.clearMatches();
                    findCount.setText("");
                } else {
                    cur.wv.findAllAsync(q);
                }
            }
        });
        findInput.setOnEditorActionListener((v, a, ev) -> {
            if (cur != null) cur.wv.findNext(true);
            hideKeyboard(findInput);
            return true;
        });
        findBar.addView(findInput, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        findCount = new TextView(this);
        findCount.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        findCount.setPadding(dp(6), 0, dp(6), 0);
        findBar.addView(findCount, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        findUp = new UiKit.Ico(this, UiKit.UP, 0xFFFFFFFF);
        findDown = new UiKit.Ico(this, UiKit.DOWN, 0xFFFFFFFF);
        findClose = new UiKit.Ico(this, UiKit.CLOSE, 0xFFFFFFFF);
        findBar.addView(cell(findUp, 22, v -> {
            if (cur != null) cur.wv.findNext(false);
        }), new LinearLayout.LayoutParams(dp(42), ViewGroup.LayoutParams.MATCH_PARENT));
        findBar.addView(cell(findDown, 22, v -> {
            if (cur != null) cur.wv.findNext(true);
        }), new LinearLayout.LayoutParams(dp(42), ViewGroup.LayoutParams.MATCH_PARENT));
        findBar.addView(cell(findClose, 20, v -> hideFind()), new LinearLayout.LayoutParams(dp(42), ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void showFind() {
        findBar.setVisibility(View.VISIBLE);
        findInput.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(findInput, InputMethodManager.SHOW_IMPLICIT);
    }

    private void hideFind() {
        if (findBar.getVisibility() != View.VISIBLE) return;
        findInput.setText("");
        findCount.setText("");
        findBar.setVisibility(View.GONE);
        hideKeyboard(findInput);
        for (Tab t : tabs) t.wv.clearMatches();
        if (cur != null) cur.wv.requestFocus();
    }

    // ------------------------------------------------------------------ snackbar (bottom message with optional action)

    private final Runnable snackHide = () -> {
        if (snackBar != null) snackBar.setVisibility(View.GONE);
    };

    void showSnack(final String msg, final String action, final Runnable onAction) {
        runOnUiThread(() -> {
            if (snackBar == null) {
                snackBar = new LinearLayout(this);
                snackBar.setOrientation(LinearLayout.HORIZONTAL);
                snackBar.setGravity(Gravity.CENTER_VERTICAL);
                snackBar.setPadding(dp(16), dp(2), dp(4), dp(2));
                snackMsg = new TextView(this);
                snackMsg.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                snackMsg.setTextColor(0xFFFFFFFF);
                snackMsg.setMaxLines(2);
                snackMsg.setEllipsize(TextUtils.TruncateAt.END);
                snackAct = new TextView(this);
                snackAct.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                snackAct.setTypeface(Typeface.DEFAULT_BOLD);
                snackAct.setTextColor(0xFFFF5560);
                snackAct.setPadding(dp(14), dp(12), dp(14), dp(12));
                snackBar.addView(snackMsg, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                snackBar.addView(snackAct, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
                lp.setMargins(dp(12), 0, dp(12), dp(68));
                rootFrame.addView(snackBar, lp);
            }
            snackBar.setBackground(roundBg(0xFF222226, 0xFF4A1419, 14));
            snackMsg.setText(msg);
            if (action != null) {
                snackAct.setVisibility(View.VISIBLE);
                snackAct.setText(action);
                snackAct.setOnClickListener(v -> {
                    snackBar.setVisibility(View.GONE);
                    if (onAction != null) onAction.run();
                });
            } else {
                snackAct.setVisibility(View.GONE);
            }
            snackBar.setVisibility(View.VISIBLE);
            snackBar.bringToFront();
            ui.removeCallbacks(snackHide);
            ui.postDelayed(snackHide, 5000);
        });
    }

    private void toast(final String s) {
        runOnUiThread(() -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show());
    }

    private static String displayUrl(String u) {
        if (u == null) return "";
        String s = u;
        if (s.startsWith("https://")) s = s.substring(8);
        else if (s.startsWith("http://")) s = s.substring(7);
        if (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    private void refreshBar() {
        if (urlBar == null) return;
        boolean priv = cur != null && cur.privateMode;
        boolean dk = isDark();
        if (!urlBar.hasFocus()) {
            urlBar.setText(cur == null || cur.url == null || cur.url.startsWith("file:") ? "" : displayUrl(cur.url));
        }
        urlBar.setHint(priv ? tr("Incognito — search or type URL", "ইনকগনিটো — সার্চ বা URL লিখুন")
                : tr("Search or type URL", "সার্চ করুন বা URL লিখুন"));
        engineBtn.setText(engineRow()[3]);
        tabCount.setText(String.valueOf(tabs.size()));
        tabCount.setTextColor(dk ? 0xFFFFFFFF : 0xFF17171A);
        GradientDrawable box = new GradientDrawable();
        box.setStroke(dp(2), priv ? 0xFFB388FF : (dk ? 0xFFFFFFFF : 0xFF26262B));
        box.setCornerRadius(dp(6));
        tabCount.setBackground(box);
        if (navBack != null && cur != null) {
            navBack.setAlpha(cur.wv.canGoBack() ? 1f : 0.35f);
            navFwd.setAlpha(cur.wv.canGoForward() ? 1f : 0.35f);
        }
        updateReloadIcon();
    }

    private void syncCur() {
        if (cur != null) {
            curId = cur.id;
            curUrl = cur.url == null ? "" : cur.url;
            curTitle = cur.title == null ? "" : cur.title;
        }
    }

    private void loadInput(String in) {
        String s = in == null ? "" : in.trim();
        if (s.length() == 0 || cur == null) return;
        String u;
        if (s.toLowerCase().startsWith("javascript:")) return;
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) {
            u = s;
        } else if (s.startsWith("localhost") || s.matches("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$")) {
            u = "http://" + s;
        } else if (!s.contains(" ") && s.contains(".") && !s.endsWith(".")) {
            u = "https://" + s;
        } else {
            u = engineRow()[2] + Uri.encode(s);
        }
        cur.wv.loadUrl(u);
    }

    // ------------------------------------------------------------------ tabs

    Tab tabById(int id) {
        for (Tab t : tabs) if (t.id == id) return t;
        return null;
    }

    void openUrlInNewTab(final String url) {
        runOnUiThread(() -> {
            if (url != null && url.length() > 0) createTab(url, null);
        });
    }

    private Tab createTab(String url, WebView existing) {
        return createTab(url, existing, false);
    }

    private Tab createTab(String url, WebView existing, boolean privateMode) {
        Tab t = new Tab();
        t.id = ++tabSeq;
        t.privateMode = privateMode;
        t.wv = existing != null ? existing : new WebView(this);
        setupWebView(t);
        tabs.add(t);
        selectTab(t);
        if (existing == null && url != null) {
            syncUA(t, url);
            t.wv.loadUrl(url);
        }
        return t;
    }

    private boolean hasPrivateTabs() {
        for (Tab tab : tabs) if (tab.privateMode) return true;
        return false;
    }

    private void restoreRegularCookiesIfNeeded() {
        if (!hasPrivateTabs()) {
            CookieManager manager = CookieManager.getInstance();
            manager.setAcceptCookie(true);
            for (Tab tab : tabs) manager.setAcceptThirdPartyCookies(tab.wv, true);
        }
    }

    private void selectTab(Tab t) {
        cur = t;
        content.removeAllViews();
        if (t.wv.getParent() instanceof ViewGroup) ((ViewGroup) t.wv.getParent()).removeView(t.wv);
        content.addView(t.wv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        progress.setVisibility(View.GONE);
        loading = false;
        hideFind();
        syncCur();
        if (urlBar != null && urlBar.hasFocus()) urlBar.clearFocus();
        refreshBar();
        t.wv.requestFocus();
    }

    private void destroyTab(Tab t, boolean wasPrivate) {
        dropHandle(t.wv);
        try {
            if (wasPrivate) {
                t.wv.clearCache(true);
                t.wv.clearHistory();
                t.wv.clearFormData();
            }
            t.wv.destroy();
        } catch (Exception ignored) {
        }
    }

    private void closeTab(Tab t) {
        if (t == null) return;
        boolean wasPrivate = t.privateMode;
        if (tabs.size() <= 1) {
            // last tab: swap it for a fresh normal home tab (so no private settings survive)
            tabs.remove(t);
            content.removeView(t.wv);
            destroyTab(t, wasPrivate);
            createTab(HOME, null, false);
            if (wasPrivate) restoreRegularCookiesIfNeeded();
            return;
        }
        int i = tabs.indexOf(t);
        tabs.remove(t);
        content.removeView(t.wv);
        destroyTab(t, wasPrivate);
        if (wasPrivate) restoreRegularCookiesIfNeeded();
        if (cur == t) selectTab(tabs.get(Math.max(0, Math.min(i, tabs.size() - 1))));
        else refreshBar();
    }

    private void closeAllTabs() {
        while (tabs.size() > 1) closeTab(tabs.get(tabs.size() - 1));
        closeTab(tabs.get(0));
    }

    private void showTabs() {
        showPanel("tabs");
    }

    // ------------------------------------------------------------------ WebView setup

    private void applyUA(WebSettings s) {
        s.setUserAgentString(desktop ? desktopUA : mobileUA);
    }

    private void setupWebView(final Tab t) {
        final WebView w = t.wv;
        w.setBackgroundColor(isDark() ? Color.BLACK : 0xFFF4F4F6);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setTextZoom(textSize);
        applyWebDark(s);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setAllowFileAccess(false);
        if (t.privateMode) {
            s.setCacheMode(WebSettings.LOAD_NO_CACHE);
            s.setDomStorageEnabled(false);
            s.setDatabaseEnabled(false);
            s.setSaveFormData(false);
        }
        applyUA(s);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(!t.privateMode && !hasPrivateTabs());
        cm.setAcceptThirdPartyCookies(w, !t.privateMode && !hasPrivateTabs());

        Bridge br = new Bridge(this, "tab", t.id);
        br.attach(w);
        w.addJavascriptInterface(br, "__DM");
        w.addJavascriptInterface(new HomeActions(t), "MahirHome");
        w.addJavascriptInterface(new BlobBridge(), "MahirBlob");
        installBootstrap(w, ext.tabBootstrap());

        w.setWebViewClient(new TabClient(t));
        w.setWebChromeClient(new TabChrome(t));
        w.setDownloadListener((url, ua, cd, mime, len) -> startDownload(url, ua, cd, mime));
        w.setFindListener((active, total, done) -> {
            if (t == cur && findInput.getText().length() > 0) {
                findCount.setText(total == 0 ? "0/0" : (active + 1) + "/" + total);
            }
        });
        w.setOnLongClickListener(v -> onLongPress(t));
    }

    void applyTextSize() {
        for (Tab t : tabs) t.wv.getSettings().setTextZoom(textSize);
    }

    // ------------------------------------------------------------------ long-press menu (links / images)

    private boolean onLongPress(final Tab t) {
        WebView.HitTestResult r = t.wv.getHitTestResult();
        if (r == null || r.getExtra() == null) return false;
        final String extra = r.getExtra();
        int type = r.getType();
        if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE) {
            linkMenu(t, extra, null);
            return true;
        }
        if (type == WebView.HitTestResult.IMAGE_TYPE) {
            linkMenu(t, null, extra);
            return true;
        }
        if (type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
            Handler h = new Handler(Looper.getMainLooper(), msg -> {
                String link = msg.getData().getString("url");
                String src = msg.getData().getString("src");
                linkMenu(t, link, src != null ? src : extra);
                return true;
            });
            t.wv.requestFocusNodeHref(h.obtainMessage());
            return true;
        }
        return false;
    }

    private void linkMenu(final Tab t, final String link, final String img) {
        final ArrayList<String> labels = new ArrayList<>();
        final ArrayList<Runnable> acts = new ArrayList<>();
        if (link != null && link.length() > 0) {
            labels.add(tr("Open in new tab", "নতুন ট্যাবে খুলুন"));
            acts.add(() -> createTab(link, null));
            labels.add(tr("Open in incognito tab", "ইনকগনিটো ট্যাবে খুলুন"));
            acts.add(() -> createTab(link, null, true));
            labels.add(tr("Copy link", "লিংক কপি করুন"));
            acts.add(() -> copyText(link));
            labels.add(tr("Share link", "লিংক শেয়ার করুন"));
            acts.add(() -> shareText(link));
        }
        if (img != null && img.length() > 0) {
            labels.add(tr("Download image", "ছবি ডাউনলোড করুন"));
            acts.add(() -> startDownload(img, t.wv.getSettings().getUserAgentString(), null, null));
            labels.add(tr("Open image in new tab", "ছবি নতুন ট্যাবে খুলুন"));
            acts.add(() -> createTab(img, null));
            labels.add(tr("Copy image address", "ছবির ঠিকানা কপি করুন"));
            acts.add(() -> copyText(img));
        }
        if (labels.isEmpty()) return;
        String title = link != null && link.length() > 0 ? link : img;
        if (title.length() > 70) title = title.substring(0, 70) + "…";
        dlg().setTitle(title)
                .setItems(labels.toArray(new String[0]), (d, which) -> acts.get(which).run())
                .show();
    }

    private void copyText(String text) {
        ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cb != null) cb.setPrimaryClip(ClipData.newPlainText("text", text));
        toast(tr("Copied", "কপি হয়েছে"));
    }

    private void shareText(String text) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(i, tr("Share", "শেয়ার")));
    }

    // ------------------------------------------------------------------ downloads

    private void registerDownloadReceiver() {
        dlReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                long id = i == null ? -1 : i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                if (id < 0) return;
                Cursor cu = null;
                try {
                    DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    cu = dm.query(new DownloadManager.Query().setFilterById(id));
                    if (cu != null && cu.moveToFirst()) {
                        int st = cu.getInt(cu.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                        String name = cu.getString(cu.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
                        final String fid = String.valueOf(id);
                        if (st == DownloadManager.STATUS_SUCCESSFUL) {
                            showSnack(tr("Downloaded: ", "ডাউনলোড হয়েছে: ") + name, tr("OPEN", "খুলুন"), () -> openDownloadItem(fid));
                            notifyDownload(tr("Download complete", "ডাউনলোড সম্পন্ন"), name);
                        } else if (st == DownloadManager.STATUS_FAILED) {
                            showSnack(tr("Download failed: ", "ডাউনলোড ব্যর্থ: ") + name, tr("VIEW", "দেখুন"), () -> showPanel("downloads"));
                            notifyDownload(tr("Download failed", "ডাউনলোড ব্যর্থ"), name);
                        }
                    }
                } catch (Exception ignored) {
                } finally {
                    if (cu != null) cu.close();
                }
            }
        };
        IntentFilter f = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(dlReceiver, f, Context.RECEIVER_EXPORTED);
        else registerReceiver(dlReceiver, f);
    }

    // Own notification: tapping it opens the Downloads screen INSIDE this browser (not the phone's Downloads app).
    private void notifyDownload(String title, String name) {
        try {
            android.app.NotificationManager nm = (android.app.NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new android.app.NotificationChannel("mahir_dl", "Downloads", android.app.NotificationManager.IMPORTANCE_DEFAULT));
            }
            Intent in = new Intent(this, MainActivity.class);
            in.putExtra("openDownloads", true);
            in.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            int fl = android.app.PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) fl |= android.app.PendingIntent.FLAG_IMMUTABLE;
            android.app.PendingIntent pi = android.app.PendingIntent.getActivity(this, 1, in, fl);
            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new android.app.Notification.Builder(this, "mahir_dl")
                    : new android.app.Notification.Builder(this);
            b.setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle(title)
                    .setContentText(name == null ? "" : name)
                    .setContentIntent(pi)
                    .setAutoCancel(true);
            nm.notify((int) (System.currentTimeMillis() % 100000), b.build());
        } catch (Exception ignored) {
        }
    }

    private boolean isApkName(String n) {
        return n != null && n.toLowerCase().endsWith(".apk");
    }

    private void startDownload(String url, String ua, String cd, String mime) {
        if (url == null) return;
        if (url.startsWith("blob:")) {
            saveBlob(url, mime);
            return;
        }
        if (url.startsWith("data:")) {
            saveDataUrl(url, cd, mime);
            return;
        }
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            toast(tr("This download is not supported", "এই ডাউনলোড সাপোর্ট করে না"));
            return;
        }
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingDl = new String[]{url, ua, cd, mime};
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            return;
        }
        try {
            String fn = URLUtil.guessFileName(url, cd, mime);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (mime != null && mime.length() > 0) r.setMimeType(mime);
            if (ua != null) r.addRequestHeader("User-Agent", ua);
            String ck = CookieManager.getInstance().getCookie(url);
            if (ck != null) r.addRequestHeader("Cookie", ck);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_HIDDEN);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fn);
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 77);
            }
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(r);
            showSnack(tr("Download started: ", "ডাউনলোড শুরু: ") + fn, tr("VIEW", "দেখুন"), () -> showPanel("downloads"));
        } catch (Exception e) {
            toast(tr("Could not start the download", "ডাউনলোড শুরু করা গেল না"));
        }
    }

    private void saveDataUrl(String url, String cd, String mime) {
        try {
            int comma = url.indexOf(',');
            if (comma < 0) throw new Exception("bad data url");
            String meta = url.substring(5, comma);
            String body = url.substring(comma + 1);
            String m = meta.split(";")[0];
            if (m.length() == 0) m = mime != null && mime.length() > 0 ? mime : "application/octet-stream";
            byte[] bytes = meta.contains(";base64") ? Base64.decode(body, Base64.DEFAULT) : Uri.decode(body).getBytes("UTF-8");
            saveBytes(URLUtil.guessFileName(url, cd, m), m, bytes);
        } catch (Exception e) {
            toast(tr("Could not save the file", "ফাইল সেভ করা গেল না"));
        }
    }

    private void saveBlob(String url, String mime) {
        if (cur == null) return;
        blobToken = UUID.randomUUID().toString();
        String js = "(function(){try{var x=new XMLHttpRequest();x.open('GET'," + JSONObject.quote(url) + ",true);x.responseType='blob';"
                + "x.onload=function(){var r=new FileReader();r.onloadend=function(){MahirBlob.save(" + JSONObject.quote(blobToken)
                + ",r.result," + JSONObject.quote(mime == null ? "" : mime) + ");};r.readAsDataURL(x.response);};"
                + "x.onerror=function(){MahirBlob.fail(" + JSONObject.quote(blobToken) + ");};x.send();}catch(e){MahirBlob.fail("
                + JSONObject.quote(blobToken) + ");}})()";
        cur.wv.evaluateJavascript(js, null);
    }

    /** Receives blob: downloads from the page. A one-time token stops pages from writing files on their own. */
    private final class BlobBridge {
        @JavascriptInterface
        public void save(String token, String dataUrl, String mime) {
            if (token == null || !token.equals(blobToken) || dataUrl == null) return;
            blobToken = null;
            saveDataUrl(dataUrl, null, mime);
        }

        @JavascriptInterface
        public void fail(String token) {
            if (token == null || !token.equals(blobToken)) return;
            blobToken = null;
            toast(tr("Could not save the file", "ফাইল সেভ করা গেল না"));
        }
    }

    /** Writes bytes into the public Downloads folder and registers them so the Downloads screen lists them. */
    private void saveBytes(String name, String mime, byte[] data) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (u == null) throw new Exception("insert failed");
            OutputStream os = getContentResolver().openOutputStream(u);
            try {
                os.write(data);
            } finally {
                os.close();
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContentResolver().update(u, done, null, null);
            Store.add(prefs, "localdl", name, u.toString(), 100);
        } else {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE));
                throw new Exception("no storage permission");
            }
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            dir.mkdirs();
            File f = new File(dir, name);
            int n = 1;
            while (f.exists()) {
                int dot = name.lastIndexOf('.');
                f = new File(dir, dot > 0 ? name.substring(0, dot) + " (" + n + ")" + name.substring(dot) : name + " (" + n + ")");
                n++;
            }
            FileOutputStream fo = new FileOutputStream(f);
            try {
                fo.write(data);
            } finally {
                fo.close();
            }
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            dm.addCompletedDownload(f.getName(), f.getName(), true, mime, f.getAbsolutePath(), f.length(), true);
        }
        showSnack(tr("Saved to Downloads: ", "ডাউনলোডে সেভ হয়েছে: ") + name, tr("VIEW", "দেখুন"), () -> showPanel("downloads"));
    }

    private static String mimeFromName(String name) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        int dot = n.lastIndexOf('.');
        String ext = dot >= 0 ? n.substring(dot + 1) : "";
        String m = ext.length() == 0 ? null : android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return m == null ? "*/*" : m;
    }

    void openDownloadItem(String id) {
        try {
            Uri u;
            String mime;
            if (id.startsWith("L")) {
                JSONObject o = Store.array(prefs, "localdl").optJSONObject(Integer.parseInt(id.substring(1)));
                if (o == null) {
                    toast(tr("File not found", "ফাইল পাওয়া যায়নি"));
                    return;
                }
                u = Uri.parse(o.optString("u"));
                mime = mimeFromName(o.optString("t"));
            } else {
                long l = Long.parseLong(id);
                DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                u = dm.getUriForDownloadedFile(l);
                mime = dm.getMimeTypeForDownloadedFile(l);
                if (mime == null) mime = "*/*";
                try {
                    Cursor nc = dm.query(new DownloadManager.Query().setFilterById(l));
                    if (nc != null) {
                        if (nc.moveToFirst() && isApkName(nc.getString(nc.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)))) {
                            mime = "application/vnd.android.package-archive";
                        }
                        nc.close();
                    }
                } catch (Exception ignored) {
                }
            }
            if (u == null) {
                toast(tr("File not found", "ফাইল পাওয়া যায়নি"));
                return;
            }
            if ("application/vnd.android.package-archive".equals(mime)) {
                if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                    toast(tr("Allow \"Install unknown apps\" for MAHIR Browser, then tap the file again",
                            "MAHIR Browser-কে \"অজানা অ্যাপ ইনস্টল\" এর অনুমতি দিন, তারপর ফাইলে আবার চাপুন"));
                    Intent st = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
                    startActivity(st);
                    return;
                }
                Intent inst = new Intent(Intent.ACTION_VIEW);
                inst.setDataAndType(u, "application/vnd.android.package-archive");
                inst.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(inst);
                return;
            }
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (android.content.ActivityNotFoundException e) {
            toast(tr("No app can open this file", "এই ফাইল খোলার মতো অ্যাপ নেই"));
        } catch (Exception e) {
            toast(tr("Could not open the file", "ফাইলটি খোলা যাচ্ছে না"));
        }
    }

    private void openDownloadsFolder() {
        showPanel("downloads");
    }

    private void dropHandle(WebView w) {
        ScriptHandler h = handles.remove(w);
        if (h != null) {
            try {
                h.remove();
            } catch (Throwable ignored) {
            }
        }
    }

    private void installBootstrap(WebView w, String js) {
        dropHandle(w);
        if (!docStart) return;
        try {
            ScriptHandler h = WebViewCompat.addDocumentStartJavaScript(w, js, Collections.singleton("*"));
            handles.put(w, h);
        } catch (Throwable ignored) {
        }
    }

    private boolean handleExternal(String u) {
        if (u == null) return false;
        String lu = u.toLowerCase();
        if (lu.startsWith("fb-messenger") || lu.startsWith("fb:") || lu.startsWith("fb-me:")
                || (lu.startsWith("market:") && lu.contains("com.facebook"))
                || (lu.startsWith("intent:") && (lu.contains("com.facebook.orca") || lu.contains("com.facebook.katana") || lu.contains("com.facebook.lite")))) {
            toast(tr("Staying in the browser", "ব্রাউজারেই থাকছে"));
            return true;
        }
        if (u.startsWith("http://") || u.startsWith("https://") || u.startsWith("about:")
                || u.startsWith("data:") || u.startsWith("blob:") || u.startsWith("javascript:")
                || u.startsWith("file:")) {
            return false;
        }
        try {
            Intent i;
            if (u.startsWith("intent:")) {
                i = Intent.parseUri(u, Intent.URI_INTENT_SCHEME);
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setComponent(null);
                i.setSelector(null);
            } else {
                i = new Intent(Intent.ACTION_VIEW, Uri.parse(u));
            }
            startActivity(i);
        } catch (Exception e) {
            toast(tr("Could not open this link", "এই লিংক খোলা গেল না"));
        }
        return true;
    }

    private final class TabClient extends WebViewClient {
        private final Tab t;

        TabClient(Tab t) {
            this.t = t;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            WebResourceResponse x = ext.serveIfExt(r.getUrl());
            if (x != null) return x;
            if (adblock && !r.isForMainFrame() && isAdHost(r.getUrl().getHost())) {
                return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
            }
            return super.shouldInterceptRequest(v, r);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            return handleExternal(r.getUrl().toString());
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap favicon) {
            if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                boolean wantDesk = desktop || needsDesk(url);
                boolean isDesk = desktopUA != null && desktopUA.equals(v.getSettings().getUserAgentString());
                if (wantDesk != isDesk) {
                    v.getSettings().setUserAgentString(wantDesk ? desktopUA : mobileUA);
                    v.stopLoading();
                    v.loadUrl(url);
                    return;
                }
            }
            t.url = url;
            if (!handles.containsKey(v)) v.evaluateJavascript(ext.tabBootstrap(), null);
            if (t == cur) {
                syncCur();
                refreshBar();
            }
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            t.url = url;
            if (!t.privateMode && savehist && url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                String ttl = v.getTitle();
                Store.add(prefs, "history", ttl != null && ttl.length() > 0 ? ttl : t.title, url, 300);
            }
            if (t == cur) {
                syncCur();
                refreshBar();
            }
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
            if (r.isForMainFrame()) {
                boolean dk = isDark();
                String u = r.getUrl().toString();
                String page = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                        + "<body style='font-family:sans-serif;text-align:center;padding:40px 16px;background:" + (dk ? "#000" : "#fff")
                        + ";color:" + (dk ? "#ddd" : "#333") + "'>"
                        + "<h2>" + tr("Page could not load", "পেজ লোড হয়নি") + "</h2><p>"
                        + tr("Check your internet connection or the address and try again.", "ইন্টারনেট বা ঠিকানা চেক করে আবার চেষ্টা করুন।") + "</p>"
                        + "<p style='color:#999;font-size:13px'>" + TextUtils.htmlEncode(String.valueOf(e.getDescription())) + "</p>"
                        + "<button onclick='location.replace(" + TextUtils.htmlEncode(JSONObject.quote(u)) + ")' "
                        + "style='margin-top:14px;padding:12px 28px;border:0;border-radius:12px;background:#e31b23;color:#fff;font-size:16px'>"
                        + tr("Retry", "আবার চেষ্টা") + "</button></body></html>";
                v.loadDataWithBaseURL(u, page, "text/html", "utf-8", u);
            }
        }
    }

    private final class TabChrome extends WebChromeClient {
        private final Tab t;

        TabChrome(Tab t) {
            this.t = t;
        }

        @Override
        public void onProgressChanged(WebView v, int p) {
            if (t != cur) return;
            progress.setProgress(p);
            progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
            boolean nowLoading = p < 100;
            if (nowLoading != loading) {
                loading = nowLoading;
                updateReloadIcon();
            }
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(final String origin, final GeolocationPermissions.Callback cb) {
            runOnUiThread(() -> dlg()
                    .setMessage(tr("Allow " + origin + " to use your location?", origin + " কে আপনার লোকেশন ব্যবহার করতে দেবেন?"))
                    .setPositiveButton(tr("Allow", "দিন"), (d, w) -> {
                        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                            cb.invoke(origin, true, false);
                        } else {
                            if (geoCb != null) geoCb.invoke(geoOrigin, false, false);
                            geoOrigin = origin;
                            geoCb = cb;
                            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
                        }
                    })
                    .setNegativeButton(tr("Block", "না"), (d, w) -> cb.invoke(origin, false, false))
                    .setOnCancelListener(d -> cb.invoke(origin, false, false))
                    .show());
        }

        @Override
        public void onReceivedTitle(WebView v, String title) {
            t.title = title == null ? "" : title;
            if (t == cur) syncCur();
        }

        @Override
        public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message resultMsg) {
            WebView nw = new WebView(MainActivity.this);
            createTab(null, nw);
            WebView.WebViewTransport tr = (WebView.WebViewTransport) resultMsg.obj;
            tr.setWebView(nw);
            resultMsg.sendToTarget();
            return true;
        }

        @Override
        public void onCloseWindow(WebView window) {
            for (Tab x : new ArrayList<>(tabs)) {
                if (x.wv == window) {
                    closeTab(x);
                    return;
                }
            }
        }

        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            try {
                startActivityForResult(p.createIntent(), REQ_FILE);
            } catch (Exception e) {
                fileCb = null;
                return false;
            }
            return true;
        }

        @Override
        public void onPermissionRequest(final PermissionRequest req) {
            runOnUiThread(() -> handlePermission(req));
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) {
                cb.onCustomViewHidden();
                return;
            }
            customView = view;
            customCb = cb;
            view.setBackgroundColor(Color.BLACK);
            rootFrame.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }

        @Override
        public void onHideCustomView() {
            hideCustom();
        }
    }

    private void hideCustom() {
        if (customView == null) return;
        rootFrame.removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        applySystemBars();
    }

    // ------------------------------------------------------------------ camera / mic permission

    private void handlePermission(PermissionRequest req) {
        ArrayList<String> need = new ArrayList<>();
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.RECORD_AUDIO);
            }
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.CAMERA);
            }
        }
        if (need.isEmpty()) {
            req.grant(req.getResources());
            return;
        }
        if (pendingPerm != null) pendingPerm.deny();
        pendingPerm = req;
        requestPermissions(need.toArray(new String[0]), REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_STORAGE) {
            boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
            String[] d = pendingDl;
            pendingDl = null;
            if (ok && d != null) startDownload(d[0], d[1], d[2], d[3]);
            else if (!ok) toast(tr("Storage permission is needed to download files", "ফাইল ডাউনলোড করতে স্টোরেজ পারমিশন লাগবে"));
            return;
        }
        if (code == REQ_LOC) {
            boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
            if (geoCb != null) geoCb.invoke(geoOrigin, ok, false);
            geoCb = null;
            geoOrigin = null;
            return;
        }
        if (code != REQ_PERM || pendingPerm == null) return;
        PermissionRequest req = pendingPerm;
        pendingPerm = null;
        ArrayList<String> ok = new ArrayList<>();
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                ok.add(r);
            } else if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                ok.add(r);
            }
        }
        if (ok.isEmpty()) req.deny();
        else req.grant(ok.toArray(new String[0]));
    }

    // ------------------------------------------------------------------ menu

    private static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
            "google-analytics.com", "googletagservices.com", "adnxs.com", "criteo.com", "criteo.net",
            "taboola.com", "outbrain.com", "pubmatic.com", "rubiconproject.com", "openx.net",
            "adsterra.com", "popads.net", "propellerads.com", "mgid.com", "scorecardresearch.com",
            "adcolony.com", "applovin.com", "unityads.unity3d.com", "moatads.com", "amazon-adsystem.com"
    };

    private boolean isAdHost(String host) {
        if (host == null) return false;
        for (String h : AD_HOSTS) if (host.equals(h) || host.endsWith("." + h)) return true;
        return false;
    }

    // ------------------------------------------------------------------ in-app screens (panel.html)

    private Dialog panelDialog;
    private WebView panelWv;

    private void showMenu() {
        showPanel("menu");
    }

    private void showSavedList(String key, String title) {
        showPanel("bookmarks".equals(key) ? "bookmarks" : "history");
    }

    private void showSettings() {
        showPanel("settings");
    }

    private void openDownloads() {
        showPanel("downloads");
    }

    private void closePanel() {
        if (panelDialog != null) {
            try {
                panelDialog.dismiss();
            } catch (Exception ignored) {
            }
        }
    }

    private void showPanel(String route) {
        if (route == null || !route.matches("menu|tabs|downloads|bookmarks|history|extensions|settings|incognito|help|about|splash")) {
            route = "menu";
        }
        if (panelDialog != null && panelDialog.isShowing() && panelWv != null) {
            if (!"splash".equals(route)) panelWv.evaluateJavascript("window.__go&&window.__go('" + route + "')", null);
            return;
        }
        final boolean dk = isDark() || "splash".equals(route);
        final Dialog d = new Dialog(this, android.R.style.Theme_Material_NoActionBar);
        final WebView w = new WebView(this);
        w.setBackgroundColor(dk ? Color.BLACK : 0xFFF4F4F6);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        w.addJavascriptInterface(new PanelActions(), "MahirPanel");
        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return true; // the panel never leaves its own local page
            }
        });
        d.setContentView(w);
        d.setOnKeyListener((dd, keyCode, ev) -> {
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                if (ev.getAction() == KeyEvent.ACTION_UP) w.evaluateJavascript("window.__back&&window.__back()", null);
                return true;
            }
            return false;
        });
        d.setOnDismissListener(x -> {
            if (panelDialog == d) {
                panelDialog = null;
                panelWv = null;
            }
            try {
                w.destroy();
            } catch (Exception ignored) {
            }
        });
        panelDialog = d;
        panelWv = w;
        d.show();
        if (d.getWindow() != null) {
            d.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
            styleDialogWindow(d.getWindow(), dk);
        }
        w.loadUrl("file:///android_asset/panel.html?l=" + rlang() + "&t=" + (dk ? "dark" : "light") + "#" + route);
    }

    private void showSplash() {
        showPanel("splash");
    }

    /** Methods the local panel page may call. Every method re-checks its own input. */
    private final class PanelActions {
        private DownloadManager dm() {
            return (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        }

        @android.webkit.JavascriptInterface
        public String state() {
            try {
                JSONObject o = new JSONObject();
                o.put("desktop", desktop);
                o.put("adblock", adblock);
                o.put("savehist", savehist);
                o.put("keepon", keepOn);
                o.put("webdark", webdark);
                o.put("theme", theme);
                o.put("lang", lang);
                o.put("rlang", rlang());
                o.put("rtheme", isDark() ? "dark" : "light");
                o.put("engine", engine);
                o.put("textSize", textSize);
                try {
                    o.put("version", getPackageManager().getPackageInfo(getPackageName(), 0).versionName);
                } catch (Exception ignored) {
                }
                JSONArray tj = new JSONArray();
                for (Tab t : new ArrayList<>(tabs)) {
                    JSONObject x = new JSONObject();
                    x.put("id", t.id);
                    x.put("title", t.title);
                    x.put("url", t.url);
                    x.put("priv", t.privateMode);
                    x.put("cur", t == cur);
                    tj.put(x);
                }
                o.put("tabs", tj);
                o.put("bookmarks", Store.array(prefs, "bookmarks"));
                o.put("history", Store.array(prefs, "history"));
                JSONArray ej = new JSONArray();
                for (Ext.Info e : ext.list()) {
                    JSONObject x = new JSONObject();
                    x.put("id", e.id);
                    x.put("name", e.name);
                    x.put("version", e.version);
                    x.put("enabled", e.enabled);
                    x.put("popup", e.popupPath() != null);
                    ej.put(x);
                }
                o.put("exts", ej);
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @android.webkit.JavascriptInterface
        public void close() {
            runOnUiThread(MainActivity.this::closePanel);
        }

        @android.webkit.JavascriptInterface
        public void go(final String u) {
            runOnUiThread(() -> {
                closePanel();
                if (u != null && u.matches("(?i)^https?://.*")) loadInput(u);
            });
        }

        @android.webkit.JavascriptInterface
        public void newTab() {
            runOnUiThread(() -> {
                closePanel();
                createTab(HOME, null);
            });
        }

        @android.webkit.JavascriptInterface
        public void newPrivate() {
            runOnUiThread(() -> {
                closePanel();
                createTab("https://www.google.com", null, true);
                toast(tr("Incognito tab opened • history, cache and cookies are off", "ইনকগনিটো ট্যাব চালু • হিস্ট্রি, ক্যাশ ও কুকি বন্ধ"));
            });
        }

        @android.webkit.JavascriptInterface
        public void messenger() {
            runOnUiThread(() -> {
                closePanel();
                openMessenger();
            });
        }

        @android.webkit.JavascriptInterface
        public void refresh() {
            runOnUiThread(() -> {
                closePanel();
                if (cur != null) cur.wv.reload();
            });
        }

        @android.webkit.JavascriptInterface
        public void share() {
            runOnUiThread(() -> {
                if (cur == null || cur.url == null || !cur.url.startsWith("http")) {
                    toast(tr("Open a page first", "আগে একটি পেজ খুলুন"));
                    return;
                }
                closePanel();
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, cur.url);
                startActivity(Intent.createChooser(i, tr("Share page", "পেজ শেয়ার")));
            });
        }

        @android.webkit.JavascriptInterface
        public void copyLink() {
            runOnUiThread(() -> {
                if (cur == null || cur.url == null || !cur.url.startsWith("http")) {
                    toast(tr("Open a page first", "আগে একটি পেজ খুলুন"));
                    return;
                }
                ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cb != null) cb.setPrimaryClip(ClipData.newPlainText("url", cur.url));
                toast(tr("Link copied", "লিংক কপি হয়েছে"));
            });
        }

        @android.webkit.JavascriptInterface
        public void exit() {
            runOnUiThread(() -> {
                closePanel();
                finish();
            });
        }

        @android.webkit.JavascriptInterface
        public void pickZip() {
            runOnUiThread(MainActivity.this::pickZip);
        }

        @android.webkit.JavascriptInterface
        public void toggle(final String key) {
            runOnUiThread(() -> {
                if ("desktop".equals(key)) {
                    toggleDesktop();
                } else if ("adblock".equals(key)) {
                    adblock = !adblock;
                    prefs.edit().putBoolean("adblock", adblock).apply();
                    if (cur != null) cur.wv.reload();
                } else if ("keepon".equals(key)) {
                    keepOn = !keepOn;
                    prefs.edit().putBoolean("keepon", keepOn).apply();
                    applyKeepOn();
                } else if ("savehist".equals(key)) {
                    savehist = !savehist;
                    prefs.edit().putBoolean("savehist", savehist).apply();
                } else if ("webdark".equals(key)) {
                    webdark = !webdark;
                    prefs.edit().putBoolean("webdark", webdark).apply();
                    for (Tab t : tabs) applyWebDark(t.wv.getSettings());
                    if (cur != null) cur.wv.reload();
                }
            });
        }

        @android.webkit.JavascriptInterface
        public String addBookmark() {
            String u = curUrl;
            if (u == null || !u.matches("(?i)^https?://.*")) return "no";
            if (Store.has(prefs, "bookmarks", u)) return "dup";
            Store.add(prefs, "bookmarks", curTitle, u, 500);
            return "ok";
        }

        @android.webkit.JavascriptInterface
        public void delBookmark(int i) {
            Store.remove(prefs, "bookmarks", i);
        }

        @android.webkit.JavascriptInterface
        public void clearHistory() {
            Store.clear(prefs, "history");
        }

        @android.webkit.JavascriptInterface
        public void clearSelected(final String csv) {
            final String k = "," + (csv == null ? "" : csv) + ",";
            if (k.contains(",h,")) Store.clear(prefs, "history");
            if (k.contains(",d,")) clearDownloads();
            runOnUiThread(() -> {
                if (k.contains(",k,")) {
                    CookieManager.getInstance().removeAllCookies(null);
                    CookieManager.getInstance().flush();
                    WebStorage.getInstance().deleteAllData();
                }
                if (k.contains(",c,")) {
                    for (Tab t : tabs) {
                        t.wv.clearCache(true);
                        t.wv.clearFormData();
                    }
                }
            });
        }

        @android.webkit.JavascriptInterface
        public void delHistory(int i) {
            Store.remove(prefs, "history", i);
        }

        @android.webkit.JavascriptInterface
        public void setTheme(String v) {
            if (!"system".equals(v) && !"light".equals(v) && !"dark".equals(v)) return;
            theme = v;
            prefs.edit().putString("theme", v).apply();
            runOnUiThread(MainActivity.this::applyTheme);
        }

        @android.webkit.JavascriptInterface
        public void setLang(String v) {
            if (!"system".equals(v) && !"en".equals(v) && !"bn".equals(v)) return;
            lang = v;
            prefs.edit().putString("lang", v).apply();
            runOnUiThread(MainActivity.this::applyTheme);
        }

        @android.webkit.JavascriptInterface
        public void setEngine(String v) {
            for (String[] e : ENGINES) {
                if (e[0].equals(v)) {
                    MainActivity.this.setEngine(v);
                    return;
                }
            }
        }

        @android.webkit.JavascriptInterface
        public void setTextSize(int pct) {
            if (pct < 50 || pct > 200) return;
            textSize = pct;
            prefs.edit().putInt("textSize", pct).apply();
            runOnUiThread(MainActivity.this::applyTextSize);
        }

        @android.webkit.JavascriptInterface
        public void translatePage() {
            runOnUiThread(() -> {
                if (cur == null || cur.url == null || !cur.url.startsWith("http")) {
                    toast(tr("Open a page first", "আগে একটি পেজ খুলুন"));
                    return;
                }
                closePanel();
                String tl = "bn".equals(rlang()) ? "bn" : "en";
                cur.wv.loadUrl("https://translate.google.com/translate?sl=auto&tl=" + tl + "&u=" + Uri.encode(cur.url));
            });
        }

        @android.webkit.JavascriptInterface
        public void openOther() {
            runOnUiThread(() -> {
                if (cur == null || cur.url == null || !cur.url.startsWith("http")) {
                    toast(tr("Open a page first", "আগে একটি পেজ খুলুন"));
                    return;
                }
                closePanel();
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(cur.url));
                    startActivity(Intent.createChooser(i, tr("Open with", "এটি দিয়ে খুলুন")));
                } catch (Exception e) {
                    toast(tr("No app found", "কোনো অ্যাপ পাওয়া যায়নি"));
                }
            });
        }

        @android.webkit.JavascriptInterface
        public void scrollEdge(final String where) {
            runOnUiThread(() -> {
                if (cur == null) return;
                closePanel();
                if ("top".equals(where)) cur.wv.scrollTo(0, 0);
                else cur.wv.pageDown(true);
            });
        }

        @android.webkit.JavascriptInterface
        public void findInPage() {
            runOnUiThread(() -> {
                closePanel();
                showFind();
            });
        }

        @android.webkit.JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                closePanel();
                printCurrent();
            });
        }

        @android.webkit.JavascriptInterface
        public void defaultBrowser() {
            runOnUiThread(MainActivity.this::requestDefaultBrowser);
        }

        @android.webkit.JavascriptInterface
        public void openDownloadsFolder() {
            runOnUiThread(MainActivity.this::openDownloadsFolder);
        }

        @android.webkit.JavascriptInterface
        public void closeAllTabs() {
            runOnUiThread(() -> {
                MainActivity.this.closeAllTabs();
                closePanel();
            });
        }

        @android.webkit.JavascriptInterface
        public void extToggle(final String id) {
            runOnUiThread(() -> {
                for (Ext.Info e : ext.list()) {
                    if (e.id.equals(id)) {
                        ext.setEnabled(e.id, !e.enabled);
                        break;
                    }
                }
                onExtensionsChanged();
            });
        }

        @android.webkit.JavascriptInterface
        public void extDelete(final String id) {
            runOnUiThread(() -> {
                ext.delete(id);
                onExtensionsChanged();
                toast(tr("Removed", "মুছে ফেলা হয়েছে"));
            });
        }

        @android.webkit.JavascriptInterface
        public void extPopup(final String id) {
            runOnUiThread(() -> {
                for (Ext.Info e : ext.list()) {
                    if (e.id.equals(id)) {
                        closePanel();
                        openPopup(e);
                        return;
                    }
                }
            });
        }

        @android.webkit.JavascriptInterface
        public void switchTab(final int id) {
            runOnUiThread(() -> {
                closePanel();
                Tab t = tabById(id);
                if (t != null) selectTab(t);
            });
        }

        @android.webkit.JavascriptInterface
        public void closeTab(final int id) {
            runOnUiThread(() -> {
                Tab t = tabById(id);
                if (t != null) MainActivity.this.closeTab(t);
            });
        }

        @android.webkit.JavascriptInterface
        public String downloads() {
            JSONArray a = new JSONArray();
            Cursor c = null;
            try {
                c = dm().query(new DownloadManager.Query());
                while (c != null && c.moveToNext() && a.length() < 200) {
                    JSONObject o = new JSONObject();
                    o.put("id", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)));
                    String name = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
                    o.put("name", name == null ? "file" : name);
                    o.put("size", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)));
                    o.put("done", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)));
                    o.put("status", c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)));
                    String mime = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE));
                    o.put("mime", mime == null ? "" : mime);
                    o.put("time", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP)));
                    a.put(o);
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.close();
            }
            // files saved directly (blob: / data: downloads on Android 10+)
            try {
                JSONArray loc = Store.array(prefs, "localdl");
                for (int i = 0; i < loc.length(); i++) {
                    JSONObject l = loc.optJSONObject(i);
                    if (l == null) continue;
                    JSONObject o = new JSONObject();
                    o.put("id", "L" + i);
                    o.put("name", l.optString("t"));
                    o.put("size", 0);
                    o.put("done", 0);
                    o.put("status", 8);
                    o.put("mime", mimeFromName(l.optString("t")));
                    o.put("time", l.optLong("ts"));
                    a.put(o);
                }
            } catch (Exception ignored) {
            }
            return a.toString();
        }

        @android.webkit.JavascriptInterface
        public void openDownload(final String id) {
            runOnUiThread(() -> openDownloadItem(id));
        }

        @android.webkit.JavascriptInterface
        public void deleteDownload(String id) {
            try {
                if (id.startsWith("L")) {
                    int idx = Integer.parseInt(id.substring(1));
                    JSONObject o = Store.array(prefs, "localdl").optJSONObject(idx);
                    if (o != null) {
                        try {
                            getContentResolver().delete(Uri.parse(o.optString("u")), null, null);
                        } catch (Exception ignored) {
                        }
                    }
                    Store.remove(prefs, "localdl", idx);
                } else {
                    dm().remove(Long.parseLong(id));
                }
            } catch (Exception ignored) {
            }
        }

        @android.webkit.JavascriptInterface
        public void clearDownloads() {
            Cursor c = null;
            try {
                c = dm().query(new DownloadManager.Query());
                ArrayList<Long> ids = new ArrayList<>();
                while (c != null && c.moveToNext()) ids.add(c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)));
                for (long id : ids) dm().remove(id);
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.close();
            }
            try {
                JSONArray loc = Store.array(prefs, "localdl");
                for (int i = 0; i < loc.length(); i++) {
                    JSONObject o = loc.optJSONObject(i);
                    if (o == null) continue;
                    try {
                        getContentResolver().delete(Uri.parse(o.optString("u")), null, null);
                    } catch (Exception ignored) {
                    }
                }
            } catch (Exception ignored) {
            }
            Store.clear(prefs, "localdl");
        }
    }

    /** Bridge for the built-in home page. Actions only work while this tab is really showing home.html. */
    private final class HomeActions {
        private final Tab t;

        HomeActions(Tab t) {
            this.t = t;
        }

        private boolean ok() {
            return t.url != null && t.url.startsWith(HOME);
        }

        @JavascriptInterface
        public String prefs() {
            try {
                JSONObject o = new JSONObject();
                o.put("lang", rlang());
                o.put("theme", isDark() ? "dark" : "light");
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void openUrl(final String u) {
            runOnUiThread(() -> {
                if (ok() && u != null && u.matches("(?i)^https?://.*")) t.wv.loadUrl(u);
            });
        }

        @JavascriptInterface
        public void showMenu() {
            runOnUiThread(() -> {
                if (ok()) MainActivity.this.showMenu();
            });
        }

        @JavascriptInterface
        public void openMessenger() {
            runOnUiThread(() -> {
                if (ok()) MainActivity.this.openMessenger();
            });
        }

        @JavascriptInterface
        public void toggleDesktop() {
            runOnUiThread(() -> {
                if (ok()) MainActivity.this.toggleDesktop();
            });
        }

        @JavascriptInterface
        public void toggleTheme() {
            runOnUiThread(() -> {
                if (!ok()) return;
                theme = isDark() ? "light" : "dark";
                prefs.edit().putString("theme", theme).apply();
                applyTheme();
            });
        }

        @JavascriptInterface
        public void panel(final String r) {
            runOnUiThread(() -> {
                if (ok()) MainActivity.this.showPanel(r);
            });
        }
    }

    private void printCurrent() {
        if (cur == null) return;
        try {
            PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            String name = cur.title != null && cur.title.length() > 0 ? cur.title : "MAHIR BROWSER";
            pm.print(name, cur.wv.createPrintDocumentAdapter(name), new PrintAttributes.Builder().build());
        } catch (Exception e) {
            toast(tr("Could not print this page", "এই পেজ প্রিন্ট করা গেল না"));
        }
    }

    private void requestDefaultBrowser() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                android.app.role.RoleManager rm = (android.app.role.RoleManager) getSystemService(Context.ROLE_SERVICE);
                if (rm != null && rm.isRoleAvailable(android.app.role.RoleManager.ROLE_BROWSER)) {
                    if (rm.isRoleHeld(android.app.role.RoleManager.ROLE_BROWSER)) {
                        toast(tr("MAHIR Browser is already the default", "MAHIR ব্রাউজার আগে থেকেই ডিফল্ট"));
                        return;
                    }
                    startActivityForResult(rm.createRequestRoleIntent(android.app.role.RoleManager.ROLE_BROWSER), REQ_ROLE);
                    return;
                }
            }
            startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));
        } catch (Exception e) {
            toast(tr("Could not open settings", "সেটিংস খোলা গেল না"));
        }
    }

    private void openMessenger() {
        // messenger.com was shut down by Meta (April 2026) and redirects to facebook.com/messages,
        // which only works as a desktop page. Always open it inside this browser, never the app.
        final String home = "https://www.facebook.com/messages";
        try {
            for (Tab t : tabs) {
                if (t.url != null && !t.privateMode && (t.url.contains("facebook.com/messages") || t.url.contains("messenger.com"))) {
                    selectTab(t);
                    return;
                }
            }
        } catch (Exception ignored) {
        }
        createTab(home, null);
    }

    private boolean needsDesk(String url) {
        if (url == null) return false;
        try {
            Uri u = Uri.parse(url);
            String h = u.getHost();
            if (h == null) return false;
            h = h.toLowerCase();
            if (h.equals("messenger.com") || h.endsWith(".messenger.com")) return true;
            if (h.equals("facebook.com") || h.endsWith(".facebook.com")) {
                String p = u.getPath() == null ? "" : u.getPath();
                return p.startsWith("/messages") || p.startsWith("/messenger");
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private void syncUA(Tab t, String url) {
        try {
            t.wv.getSettings().setUserAgentString((desktop || needsDesk(url)) ? desktopUA : mobileUA);
        } catch (Exception ignored) {
        }
    }

    private void applyKeepOn() {
        try {
            if (keepOn) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } catch (Exception ignored) {
        }
    }

    private void toggleDesktop() {
        desktop = !desktop;
        prefs.edit().putBoolean("desktop", desktop).apply();
        for (Tab t : tabs) applyUA(t.wv.getSettings());
        if (cur != null) cur.wv.reload();
        toast(desktop ? tr("Desktop mode on", "ডেস্কটপ মোড চালু") : tr("Desktop mode off", "ডেস্কটপ মোড বন্ধ"));
    }

    // ------------------------------------------------------------------ extensions UI

    private void showExtensions() {
        showPanel("extensions");
    }

    private void pickZip() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/zip", "application/x-zip-compressed", "application/x-zip", "application/octet-stream"});
        try {
            startActivityForResult(i, REQ_ZIP);
        } catch (Exception e) {
            toast(tr("Could not open the file picker", "ফাইল পিকার খোলা গেল না"));
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE) {
            if (fileCb != null) {
                Uri[] r = WebChromeClient.FileChooserParams.parseResult(res, data);
                fileCb.onReceiveValue(r);
                fileCb = null;
            }
        } else if (req == REQ_ZIP) {
            if (res == RESULT_OK && data != null && data.getData() != null) installZip(data.getData());
        }
    }

    private void installZip(final Uri uri) {
        toast(tr("Adding extension...", "এক্সটেনশন যোগ হচ্ছে..."));
        new Thread(() -> {
            try {
                InputStream in = getContentResolver().openInputStream(uri);
                if (in == null) throw new Exception("ফাইল পড়া যায়নি");
                final Ext.Info info;
                try {
                    info = ext.install(in);
                } finally {
                    in.close();
                }
                runOnUiThread(() -> {
                    toast(tr("Added: ", "যোগ হয়েছে: ") + (info == null ? "" : info.name));
                    onExtensionsChanged();
                    if (cur != null) cur.wv.reload();
                });
            } catch (final Exception e) {
                runOnUiThread(() -> toast(tr("ZIP failed: ", "জিপ কাজ করেনি: ") + e.getMessage()));
            }
        }).start();
    }

    private void onExtensionsChanged() {
        refreshExtensions();
        if (panelWv != null) panelWv.evaluateJavascript("window.__refresh&&window.__refresh()", null);
    }

    /** Rebuilds background pages and re-registers the content-script bootstrap in every tab. */
    private void refreshExtensions() {
        for (BgPage b : bgs.values()) {
            rootFrame.removeView(b.wv);
            dropHandle(b.wv);
            try {
                b.wv.destroy();
            } catch (Exception ignored) {
            }
        }
        bgs.clear();
        for (Ext.Info i : ext.list()) {
            if (i.enabled && i.hasBackground()) createBg(i);
        }
        String js = ext.tabBootstrap();
        for (Tab t : tabs) installBootstrap(t.wv, js);
    }

    // ------------------------------------------------------------------ extension pages (background / popup)

    private void configureExtWebView(WebView w, String kind, String extId) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        Bridge br = new Bridge(this, kind, 0);
        br.attach(w);
        w.addJavascriptInterface(br, "__DM");
        installBootstrap(w, ext.pageBootstrap(extId));
    }

    private final class ExtPageClient extends WebViewClient {
        private final String extId;
        private final Runnable onFinish;

        ExtPageClient(String extId, Runnable onFinish) {
            this.extId = extId;
            this.onFinish = onFinish;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            WebResourceResponse x = ext.serveIfExt(r.getUrl());
            return x != null ? x : super.shouldInterceptRequest(v, r);
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap f) {
            if (!handles.containsKey(v)) v.evaluateJavascript(ext.pageBootstrap(extId), null);
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            if (onFinish != null) onFinish.run();
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            if (EXT_HOST.equals(r.getUrl().getHost())) return false;
            openUrlInNewTab(r.getUrl().toString());
            return true;
        }
    }

    private void createBg(Ext.Info i) {
        final BgPage b = new BgPage();
        b.extId = i.id;
        b.wv = new WebView(this);
        configureExtWebView(b.wv, "bg", i.id);
        b.wv.setWebViewClient(new ExtPageClient(i.id, () -> {
            if (!b.loaded) {
                b.loaded = true;
                ArrayList<Runnable> q = new ArrayList<>(b.queue);
                b.queue.clear();
                for (Runnable r : q) r.run();
            }
        }));
        b.wv.setAlpha(0f);
        rootFrame.addView(b.wv, new FrameLayout.LayoutParams(1, 1));
        bgs.put(i.id, b);
        b.wv.loadUrl("https://" + EXT_HOST + Ext.PREFIX + i.id + "/_bg.html");
    }

    private void openPopup(Ext.Info e) {
        String p = e.popupPath();
        if (p == null) {
            toast(tr("This extension has no popup", "এই এক্সটেনশনে পপআপ নেই"));
            return;
        }
        final Dialog d = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(Color.BLACK);

        TextView title = new TextView(this);
        title.setText("✕   " + e.name);
        title.setTextColor(0xFFFFD27A);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(14), 0, dp(14), 0);
        title.setBackgroundColor(0xFF111111);
        title.setOnClickListener(v -> d.dismiss());

        final WebView w = new WebView(this);
        w.setBackgroundColor(Color.BLACK);
        configureExtWebView(w, "popup", e.id);
        w.setWebViewClient(new ExtPageClient(e.id, null));
        popupViews.add(w);

        box.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
        box.addView(w, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        d.setContentView(box);
        d.setOnDismissListener(x -> {
            popupViews.remove(w);
            dropHandle(w);
            try {
                w.destroy();
            } catch (Exception ignored) {
            }
        });
        d.show();
        if (d.getWindow() != null) {
            d.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        }
        w.loadUrl("https://" + EXT_HOST + Ext.PREFIX + e.id + "/" + p);
    }

    // ------------------------------------------------------------------ message routing (called by Bridge)

    private String senderJson(Bridge from, String extId) {
        JSONObject s = new JSONObject();
        try {
            s.put("id", extId);
            if ("tab".equals(from.kindName())) {
                Tab t = tabById(from.tabIdValue());
                JSONObject tb = new JSONObject();
                tb.put("id", from.tabIdValue());
                tb.put("url", t == null || t.url == null ? "" : t.url);
                tb.put("title", t == null || t.title == null ? "" : t.title);
                s.put("tab", tb);
                s.put("frameId", 0);
                s.put("url", t == null || t.url == null ? "" : t.url);
            }
        } catch (JSONException ignored) {
        }
        return s.toString();
    }

    void route(final Bridge from, final String extId, final String target, final int destTab,
               final String msg, final int cbId) {
        runOnUiThread(() -> {
            final int rid = ++respSeq;
            pending.put(rid, new Pending(from.webView(), cbId));
            final String sender = senderJson(from, extId);
            if ("bg".equals(target)) {
                final BgPage b = bgs.get(extId);
                if (b == null) {
                    respond(rid, "null");
                    return;
                }
                b.post(() -> deliver(b.wv, extId, msg, sender, rid));
            } else {
                Tab t = tabById(destTab);
                if (t == null) {
                    respond(rid, "null");
                    return;
                }
                deliver(t.wv, extId, msg, sender, rid);
            }
        });
    }

    private void deliver(WebView dest, String extId, String msg, String sender, final int rid) {
        String js = "(window.__dmDeliver?(window.__dmDeliver(" + JSONObject.quote(extId) + ","
                + JSONObject.quote(msg == null ? "null" : msg) + "," + JSONObject.quote(sender) + "," + rid + "),1):0)";
        dest.evaluateJavascript(js, value -> {
            if (!"1".equals(value)) respond(rid, "null");
        });
    }

    void respond(final int rid, final String json) {
        runOnUiThread(() -> {
            Pending p = pending.remove(rid);
            if (p == null) return;
            WebView w = p.wv.get();
            if (w != null) {
                w.evaluateJavascript("window.__dmCb&&window.__dmCb(" + p.cb + ","
                        + JSONObject.quote(json == null ? "null" : json) + ")", null);
            }
        });
    }

    void broadcastChanges(final String extId, final String changesJson) {
        runOnUiThread(() -> {
            final String js = "window.__dmChanged&&window.__dmChanged(" + JSONObject.quote(extId) + ","
                    + JSONObject.quote(changesJson) + ",'local')";
            for (Tab t : tabs) t.wv.evaluateJavascript(js, null);
            for (final BgPage b : bgs.values()) b.post(() -> b.wv.evaluateJavascript(js, null));
            for (WebView w : new ArrayList<>(popupViews)) w.evaluateJavascript(js, null);
        });
    }
}
