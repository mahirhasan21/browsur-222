package com.dragon.browser;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.View;

/** Hand-drawn vector icons + a toggle switch, so the UI needs no image assets. */
final class UiKit {
    private UiKit() {
    }

    static final int PLUS = 1, INCOG = 2, BOOKMARK = 3, CLOCK = 4, DOWNLOAD = 5, DESKTOP = 6,
            EXT = 7, GEAR = 8, HELP = 9, INFO = 10, EXIT = 11, BACK = 12, FORWARD = 13, HOME = 14,
            CHEV = 15, REFRESH = 16, COPY = 17, SHARE = 18, STAR = 19, DOTS = 20, CROWN = 21,
            ARROW = 22, BOLT = 23, CLOSE = 24, UP = 25, DOWN = 26;

    static final int B_GOOGLE = 101, B_YOUTUBE = 102, B_FACEBOOK = 103, B_MESSENGER = 104,
            B_WHATSAPP = 105, B_TELEGRAM = 106, B_X = 107, B_MORE = 108;

    interface OnChange {
        void on(boolean value);
    }

    // ------------------------------------------------------------------ icons

    static final class Ico extends View {
        private int type;
        private int color;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final RectF r = new RectF();

        Ico(Context c, int type, int color) {
            super(c);
            this.type = type;
            this.color = color;
        }

        void setType(int t) {
            type = t;
            invalidate();
        }

        void setColor(int c) {
            color = c;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float s = Math.min(getWidth(), getHeight()) / 24f;
            c.save();
            c.translate((getWidth() - 24f * s) / 2f, (getHeight() - 24f * s) / 2f);
            c.scale(s, s);
            stroke();
            if (type >= 100) brand(c);
            else glyph(c);
            c.restore();
        }

        private void stroke() {
            p.reset();
            p.setAntiAlias(true);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.8f);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setColor(color);
        }

        private void fill(int col) {
            p.reset();
            p.setAntiAlias(true);
            p.setStyle(Paint.Style.FILL);
            p.setColor(col);
        }

        private void poly(Canvas c, boolean close, float... pts) {
            path.reset();
            path.moveTo(pts[0], pts[1]);
            for (int i = 2; i + 1 < pts.length; i += 2) path.lineTo(pts[i], pts[i + 1]);
            if (close) path.close();
            c.drawPath(path, p);
        }

        private void line(Canvas c, float a, float b, float x, float y) {
            c.drawLine(a, b, x, y, p);
        }

        private void glyph(Canvas c) {
            switch (type) {
                case PLUS:
                    line(c, 12, 5, 12, 19);
                    line(c, 5, 12, 19, 12);
                    break;
                case INCOG:
                    poly(c, false, 5, 11, 7.5f, 4.5f, 16.5f, 4.5f, 19, 11);
                    line(c, 3, 11, 21, 11);
                    c.drawCircle(8, 16.5f, 2.6f, p);
                    c.drawCircle(16, 16.5f, 2.6f, p);
                    line(c, 10.6f, 16, 13.4f, 16);
                    break;
                case BOOKMARK:
                    poly(c, true, 7, 4, 17, 4, 17, 20, 12, 16, 7, 20);
                    break;
                case CLOCK:
                    c.drawCircle(12, 12, 8.5f, p);
                    poly(c, false, 12, 7.5f, 12, 12, 15.2f, 14);
                    break;
                case DOWNLOAD:
                    line(c, 12, 4, 12, 14.5f);
                    poly(c, false, 7.5f, 10.5f, 12, 15, 16.5f, 10.5f);
                    line(c, 5, 19, 19, 19);
                    break;
                case DESKTOP:
                    r.set(3, 4, 21, 16);
                    c.drawRoundRect(r, 2, 2, p);
                    line(c, 12, 16, 12, 20);
                    line(c, 8, 20, 16, 20);
                    break;
                case EXT:
                    r.set(4, 4, 10.5f, 10.5f);
                    c.drawRoundRect(r, 1.4f, 1.4f, p);
                    r.set(4, 13, 10.5f, 19.5f);
                    c.drawRoundRect(r, 1.4f, 1.4f, p);
                    r.set(13, 13, 19.5f, 19.5f);
                    c.drawRoundRect(r, 1.4f, 1.4f, p);
                    poly(c, true, 16.5f, 3.7f, 20.3f, 7.5f, 16.5f, 11.3f, 12.7f, 7.5f);
                    break;
                case GEAR:
                    c.drawCircle(12, 12, 3, p);
                    c.drawCircle(12, 12, 6.6f, p);
                    for (int k = 0; k < 8; k++) {
                        double a = Math.toRadians(k * 45);
                        float cx = (float) Math.cos(a), cy = (float) Math.sin(a);
                        line(c, 12 + 6.6f * cx, 12 + 6.6f * cy, 12 + 9.6f * cx, 12 + 9.6f * cy);
                    }
                    break;
                case HELP:
                    c.drawCircle(12, 12, 9, p);
                    fill(color);
                    p.setTypeface(Typeface.DEFAULT_BOLD);
                    p.setTextSize(13);
                    p.setTextAlign(Paint.Align.CENTER);
                    c.drawText("?", 12, 16.5f, p);
                    break;
                case INFO:
                    c.drawCircle(12, 12, 9, p);
                    line(c, 12, 11, 12, 16.8f);
                    fill(color);
                    c.drawCircle(12, 7.8f, 1.1f, p);
                    break;
                case EXIT:
                    poly(c, false, 10, 4, 5, 4, 5, 20, 10, 20);
                    line(c, 9.5f, 12, 20, 12);
                    poly(c, false, 16, 8, 20, 12, 16, 16);
                    break;
                case BACK:
                    poly(c, false, 15, 5, 8, 12, 15, 19);
                    break;
                case FORWARD:
                    poly(c, false, 9, 5, 16, 12, 9, 19);
                    break;
                case CHEV:
                    poly(c, false, 9, 6, 15, 12, 9, 18);
                    break;
                case HOME:
                    fill(color);
                    poly(c, true, 12, 3.5f, 21, 11.5f, 18.5f, 11.5f, 18.5f, 20, 14, 20, 14, 14.5f,
                            10, 14.5f, 10, 20, 5.5f, 20, 5.5f, 11.5f, 3, 11.5f);
                    break;
                case REFRESH:
                    r.set(5, 5, 19, 19);
                    c.drawArc(r, -50, 280, false, p);
                    poly(c, false, 16.5f, 3, 16.5f, 6.8f, 20.2f, 6.8f);
                    break;
                case COPY:
                    r.set(9, 9, 19.5f, 19.5f);
                    c.drawRoundRect(r, 2, 2, p);
                    poly(c, false, 5, 14.5f, 5, 5, 14.5f, 5, 14.5f, 8);
                    break;
                case SHARE:
                    c.drawCircle(6, 12, 2.4f, p);
                    c.drawCircle(18, 5.8f, 2.4f, p);
                    c.drawCircle(18, 18.2f, 2.4f, p);
                    line(c, 8.2f, 10.9f, 15.8f, 6.9f);
                    line(c, 8.2f, 13.1f, 15.8f, 17.1f);
                    break;
                case STAR: {
                    fill(color);
                    path.reset();
                    for (int i = 0; i < 10; i++) {
                        double a = Math.toRadians(-90 + 36 * i);
                        float rr = (i % 2 == 0) ? 9.5f : 4.1f;
                        float x = 12 + rr * (float) Math.cos(a);
                        float y = 12.6f + rr * (float) Math.sin(a);
                        if (i == 0) path.moveTo(x, y);
                        else path.lineTo(x, y);
                    }
                    path.close();
                    c.drawPath(path, p);
                    break;
                }
                case DOTS:
                    fill(color);
                    c.drawCircle(12, 5, 1.9f, p);
                    c.drawCircle(12, 12, 1.9f, p);
                    c.drawCircle(12, 19, 1.9f, p);
                    break;
                case CROWN:
                    poly(c, true, 3, 18, 4.5f, 8, 8.7f, 12.5f, 12, 6, 15.3f, 12.5f, 19.5f, 8, 21, 18);
                    line(c, 3.5f, 21, 20.5f, 21);
                    break;
                case ARROW:
                    line(c, 5, 12, 19, 12);
                    poly(c, false, 13, 6, 19, 12, 13, 18);
                    break;
                case CLOSE:
                    line(c, 6, 6, 18, 18);
                    line(c, 18, 6, 6, 18);
                    break;
                case UP:
                    poly(c, false, 5, 15, 12, 8, 19, 15);
                    break;
                case DOWN:
                    poly(c, false, 5, 9, 12, 16, 19, 9);
                    break;
                case BOLT:
                    fill(color);
                    poly(c, true, 13.5f, 2.5f, 5.5f, 13.5f, 11, 13.5f, 10, 21.5f, 18.5f, 10, 12.5f, 10);
                    break;
                default:
                    break;
            }
        }

        private void brand(Canvas c) {
            switch (type) {
                case B_GOOGLE:
                    fill(0xFFFFFFFF);
                    p.setTypeface(Typeface.DEFAULT_BOLD);
                    p.setTextSize(23);
                    p.setTextAlign(Paint.Align.CENTER);
                    p.setShader(new SweepGradient(12, 12,
                            new int[]{0xFF4285F4, 0xFF34A853, 0xFFFBBC05, 0xFFEA4335, 0xFF4285F4}, null));
                    c.drawText("G", 12, 20, p);
                    break;
                case B_YOUTUBE:
                    fill(0xFFFF0000);
                    r.set(1.5f, 5, 22.5f, 19);
                    c.drawRoundRect(r, 4.5f, 4.5f, p);
                    fill(0xFFFFFFFF);
                    poly(c, true, 10, 8.8f, 10, 15.2f, 15.6f, 12);
                    break;
                case B_FACEBOOK:
                    fill(0xFF1877F2);
                    c.drawCircle(12, 12, 10.5f, p);
                    fill(0xFFFFFFFF);
                    p.setTypeface(Typeface.DEFAULT_BOLD);
                    p.setTextSize(21);
                    p.setTextAlign(Paint.Align.CENTER);
                    c.drawText("f", 13.2f, 21.2f, p);
                    break;
                case B_MESSENGER:
                    fill(0xFFFFFFFF);
                    p.setShader(new LinearGradient(3, 21, 21, 3,
                            new int[]{0xFF0099FF, 0xFFA033FF, 0xFFFF5280}, null, Shader.TileMode.CLAMP));
                    c.drawCircle(12, 12, 10.5f, p);
                    fill(0xFFFFFFFF);
                    c.drawCircle(12, 11.5f, 6.9f, p);
                    poly(c, true, 7.4f, 15.6f, 7.2f, 19.2f, 10.8f, 17.4f);
                    fill(0xFFA033FF);
                    poly(c, true, 6.6f, 13.9f, 10.6f, 9.5f, 12.5f, 11.6f, 16.4f, 9.5f, 12.9f, 13.9f, 11f, 11.8f);
                    break;
                case B_WHATSAPP:
                    fill(0xFF25D366);
                    c.drawCircle(12, 12, 10.5f, p);
                    stroke();
                    p.setColor(0xFFFFFFFF);
                    p.setStrokeWidth(1.7f);
                    c.drawCircle(12, 11.7f, 5.6f, p);
                    p.setStrokeWidth(2.4f);
                    line(c, 9.6f, 9.6f, 14.4f, 14.4f);
                    fill(0xFFFFFFFF);
                    poly(c, true, 6.2f, 18.2f, 7.4f, 14.4f, 9.8f, 16.6f);
                    break;
                case B_TELEGRAM:
                    fill(0xFF2AABEE);
                    c.drawCircle(12, 12, 10.5f, p);
                    fill(0xFFFFFFFF);
                    poly(c, true, 5.4f, 11.8f, 18.4f, 6.8f, 15.9f, 17.8f, 12, 15, 10, 17.2f, 9.6f, 13.6f);
                    break;
                case B_X:
                    stroke();
                    p.setColor(0xFFFFFFFF);
                    p.setStrokeWidth(2.2f);
                    line(c, 6.5f, 5.5f, 17.5f, 18.5f);
                    line(c, 17.5f, 5.5f, 6.5f, 18.5f);
                    break;
                case B_MORE:
                    stroke();
                    p.setColor(0xFFFFFFFF);
                    p.setStrokeWidth(1.6f);
                    c.drawCircle(7.5f, 7.5f, 3, p);
                    c.drawCircle(16.5f, 7.5f, 3, p);
                    c.drawCircle(7.5f, 16.5f, 3, p);
                    c.drawCircle(16.5f, 16.5f, 3, p);
                    break;
                default:
                    break;
            }
        }
    }

    // ------------------------------------------------------------------ toggle switch

    static final class Toggle extends View {
        private boolean on;
        private OnChange cb;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final float d;

        Toggle(Context c, boolean on) {
            super(c);
            this.on = on;
            this.d = c.getResources().getDisplayMetrics().density;
            setOnClickListener(v -> {
                this.on = !this.on;
                invalidate();
                if (cb != null) cb.on(this.on);
            });
        }

        void setOnChange(OnChange c) {
            cb = c;
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension((int) (46 * d), (int) (26 * d));
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setColor(on ? 0xFFE31B23 : 0xFF3A3A3A);
            r.set(0, 0, w, h);
            c.drawRoundRect(r, h / 2, h / 2, p);
            p.setColor(0xFFFFFFFF);
            float cx = on ? w - h / 2 : h / 2;
            c.drawCircle(cx, h / 2, h / 2 - 3 * d, p);
        }
    }
}
