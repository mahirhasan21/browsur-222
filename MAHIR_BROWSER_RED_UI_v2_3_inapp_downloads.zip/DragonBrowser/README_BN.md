# MAHIR BROWSER — Android Studio Project

এটি একটি Android WebView-ভিত্তিক ব্রাউজার প্রজেক্ট। অ্যাপের হোমপেজ, শর্টকাট, সার্চ, ট্যাব বার ও মেনু নতুন Obsidian Aurora (dark violet + cyan) UI-তে সাজানো হয়েছে।

## প্রধান ফিচার

- ওয়েবসাইট ও Google Search খোলা
- Google, YouTube, Facebook, Messenger, WhatsApp, Telegram, Instagram, X, Gmail, Maps ও Wikipedia শর্টকাট
- একাধিক ট্যাব তৈরি, বদলানো ও বন্ধ করা
- নিচ থেকে ওঠা 3-dot quick menu
- Bookmarks ও সর্বশেষ 100টি normal browsing history entry
- Android Download Manager-এ ফাইল ডাউনলোড
- Private Tab: history save করে না, WebView cache ও DOM storage বন্ধ রাখে এবং private tab খোলা থাকা অবস্থায় cookies গ্রহণ বন্ধ রাখে
- Desktop Mode
- Extension ZIP picker (প্রজেক্টের extension engine অনুযায়ী)
- Share page, refresh, clear cache/cookies
- GitHub Actions workflow দিয়ে Debug APK build

## APK বানানোর নিয়ম

1. ZIP extract করে `DragonBrowser` ফোল্ডারটি GitHub repository-তে upload করুন।
2. GitHub repository-র **Actions** tab খুলুন।
3. **Build MAHIR BROWSER APK** workflow নির্বাচন করে **Run workflow** চাপুন।
4. Build সফল হলে `MAHIR-BROWSER-debug-apk` artifact থেকে `app-debug.apk` download করুন।

অথবা Android Studio-তে `DragonBrowser` ফোল্ডারটি Open করে Gradle Sync শেষে **Build > Build APK(s)** নির্বাচন করুন।

## গুরুত্বপূর্ণ নোট

- এটি WebView browser; কিছু ওয়েবসাইট তাদের নিজস্ব অ্যাপ বা পূর্ণ Chrome browser চাইতে পারে।
- Private Tab চালু থাকলে cookie acceptance অ্যাপের সব WebView tab-এর জন্য সাময়িকভাবে বন্ধ থাকে; শেষ private tab বন্ধ হলে আবার চালু হয়। এটি আলাদা Android profile নয়।
- কিছু সাইটের camera/microphone ব্যবহার করতে Android permission চাইতে পারে।
- APK এই পরিবেশে Android SDK দিয়ে build/run করে পরীক্ষা করা যায়নি; GitHub Actions বা Android Studio-তে প্রথম build যাচাই করুন।

## নতুন লাল (Red Neon) UI

- Splash, হোম, মেনু, Bookmarks, History, Downloads, Extensions, Settings, Incognito, Tabs — সব স্ক্রিন এখন একই লাল-কালো ডিজাইনে (`assets/panel.html`, `assets/home.html`, `assets/ui.css`)।
- আগের ধূসর Android ডায়ালগ আর নেই।
- Settings-এ Ad Blocker (সহজ হোস্ট-লিস্ট ভিত্তিক), Desktop Mode, History save চালু/বন্ধ করা যায়।
- Downloads স্ক্রিন Android DownloadManager থেকে এই অ্যাপের ডাউনলোড দেখায়।
- এই পরিবেশে Android SDK না থাকায় APK build করে ফোনে চালানো যায়নি; HTML স্ক্রিনগুলো ব্রাউজারে পরীক্ষা করা হয়েছে। প্রথম build GitHub Actions/Android Studio-তে যাচাই করুন।


## v2 আপডেট — নতুন ফিচার ও ফিক্স

**নতুন**
- **থিম:** System / Light (সাদা) / Dark — মেনু ও Settings ও হোমের "থিম" বাটন থেকে। নেটিভ বার, মেনু, হোম সব বদলায়। "ওয়েবসাইটে ডার্ক মোড" আলাদা চালু/বন্ধ করা যায়।
- **ভাষা:** System / English / বাংলা — মেনু, Settings ও হোম থেকে (সব স্ক্রিন, মেসেজ ও ডায়ালগ বদলায়)।
- **সার্চ ইঞ্জিন:** Google, Bing, DuckDuckGo, Yahoo, Brave — উপরের বাঁ দিকের অক্ষর বাটনে চাপলেই বদলানো যায়।
- **URL বার:** রিফ্রেশ/স্টপ/ক্লিয়ার বাটন।
- **Find in page** (পেজে খোঁজা), **Print / Save as PDF**, লেখার আকার (75%–175%), **Default browser** সেট করা।
- **লং-প্রেস মেনু:** লিংকে — নতুন ট্যাব, ইনকগনিটো ট্যাব, কপি, শেয়ার; ছবিতে — ডাউনলোড, নতুন ট্যাবে খোলা, ঠিকানা কপি।
- **Clear browsing data:** হিস্ট্রি / ক্যাশ / কুকি / ডাউনলোড তালিকা আলাদা বেছে মোছা যায়।
- ট্যাব স্ক্রিনে **Close all**; হিস্ট্রির আইটেম আলাদা করে মোছা; লোকেশন চাইলে অনুমতির ডায়ালগ।

**ফিক্স**
- ব্রাউজিংয়ের পর Home চাপলে হোমের বাটন কাজ না করা (JS ইন্টারফেস বাগ) — এখন প্রতিটি ট্যাবে নিরাপদভাবে সংযুক্ত; ওয়েবসাইট এই ইন্টারফেস ব্যবহার করতে পারে না।
- উপরের "G" বাটনে কিছু হতো না — এখন সার্চ ইঞ্জিন বাছাই।
- **ডাউনলোড:** শুরু/শেষ/ব্যর্থ হলে নিচে মেসেজ (Open / View বাটনসহ); Downloads স্ক্রিন লাইভ আপডেট হয় ও "Open Downloads folder" বাটন আছে; Android 9 বা নিচে স্টোরেজ পারমিশন চাওয়া হয় (আগে চাইত না বলে ডাউনলোড ফেল করত); `blob:` ও `data:` লিংকের ডাউনলোড এখন কাজ করে।
- শেষ ট্যাব বন্ধ করলে (বিশেষ করে ইনকগনিটো) নতুন পরিষ্কার ট্যাব খোলে, আগের প্রাইভেট সেটিং থেকে যায় না।
- ব্যাক চাপলে আগে ফাইন্ড বার/URL বার বন্ধ হয়; এরর পেজে Retry বাটন; Messenger অ্যাপ Android 11+ এও ডিটেক্ট হয়।
- ডাউনলোড ফিক্স ও থিম/ভাষা যাচাই করতে নতুন কোড প্রথমবার Android Studio বা GitHub Actions-এ build করে ফোনে টেস্ট করে দেখুন।

## v2.2 পরিবর্তন
- **Messenger ঠিক করা হয়েছে:** Meta ২০২৬ সালের এপ্রিলে messenger.com বন্ধ করে দিয়েছে (এখন facebook.com/messages-এ যায়)। তাই Messenger লোগো / Quick Open এখন সবসময় ব্রাউজারের ভেতরেই `facebook.com/messages` খোলে, Messenger অ্যাপে আর যায় না।
- Messenger / Facebook messages পেজে অটো Desktop UA চালু হয় (মোবাইল UA দিলে ওরা অ্যাপে পাঠায়), বাকি সাইটে আগের মতো মোবাইল থাকে।
- fb-messenger://, intent://…com.facebook.orca, market:// লিংক এখন অ্যাপ খুলতে পারে না, ব্রাউজারেই থাকে।
- নতুন মেনু: পেজ অনুবাদ (Google Translate), অন্য অ্যাপে খুলুন, একদম উপরে / নিচে যান, স্ক্রিন জাগিয়ে রাখুন।
- হোমে নতুন শর্টকাট: Instagram, Discord, imo, Likee, TikTok; নতুন সুন্দর Messenger লোগো।

## v2.3 পরিবর্তন (ডাউনলোড ব্রাউজারের ভেতরেই)
- Downloads স্ক্রিন সম্পূর্ণ অ্যাপের ভেতরে; "Open Downloads folder" বাটন সরানো হয়েছে, ফোনের ফাইল ম্যানেজার / Downloads অ্যাপে আর যায় না।
- ডাউনলোডের নোটিফিকেশন এখন নিজেদের (MAHIR Browser); চাপলে সরাসরি ব্রাউজারের Downloads স্ক্রিন খোলে।
- APK ডাউনলোড হলে লিস্টে চাপলেই ইনস্টল শুরু হয়। প্রথমবার "Install unknown apps" অনুমতি একবার দিতে হবে (Chrome-এর মতোই)।
